package spring.demo;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class MainSpringBean {
	public static void main(String[] args) {
		
//		ApplicationContext context = new FileSystemXmlApplicationContext("E:\\spring-config2.xml");
		ApplicationContext context = new ClassPathXmlApplicationContext("spring-config.xml");
		BeanFactory factory = context;
		House house = (House) factory.getBean("houseBean");
		
		house.getAnimal1().makeSound();
		house.getAnimal2().makeSound();
	}
}
