package spring.demo;

public interface Animal {

	void makeSound();

}
