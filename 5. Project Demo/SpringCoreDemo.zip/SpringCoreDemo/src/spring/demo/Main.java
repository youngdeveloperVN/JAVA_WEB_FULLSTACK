package spring.demo;

public class Main {
	public static void main(String[] args) {
		
		//1. create house
		House house = new House();
		
		//2. create cat, dog
		Animal animal1 = new Dog();
		Animal animal2 = new Cat();
		
		//3. associate house <=> cat and dog
		house.setAnimal1(animal1);
		house.setAnimal2(animal2);
		
		house.getAnimal1().makeSound();
		house.getAnimal2().makeSound();
		
	}
}
