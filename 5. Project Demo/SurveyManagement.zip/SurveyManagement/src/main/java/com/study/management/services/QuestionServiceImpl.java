package com.study.management.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.study.management.entities.Question;
import com.study.management.repository.QuestiontRepository;

@Component
public class QuestionServiceImpl implements QuestionService {

	@Autowired
	private QuestiontRepository questionRepository;
	
	@Override
	public List<Question> getAllQuestion() {
		return questionRepository.findAllQuestion();
	}

}
