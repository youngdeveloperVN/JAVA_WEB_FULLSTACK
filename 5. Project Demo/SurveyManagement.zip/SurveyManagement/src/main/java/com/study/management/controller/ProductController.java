package com.study.management.controller;
//package com.question.management.controller;
//
//import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.ResponseBody;
//
//import com.question.management.vo.QuestionVO;
//
//@Controller
//public class QuestionController {
//	
//	@RequestMapping(value = "/question", method = RequestMethod.GET, produces = "application/json")
//	@ResponseBody
//	public QuestionVO getQuestion() {
//		QuestionVO question = new QuestionVO();
//		question.setName("Huy");
//		question.setId(12);
//		return question;
//	}
//}
