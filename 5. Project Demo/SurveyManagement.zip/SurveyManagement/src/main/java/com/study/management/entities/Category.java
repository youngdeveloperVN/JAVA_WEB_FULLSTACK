package com.study.management.entities;

public class Category {

}
