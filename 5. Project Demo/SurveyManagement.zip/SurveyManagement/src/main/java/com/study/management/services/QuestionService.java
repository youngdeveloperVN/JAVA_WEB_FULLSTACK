package com.study.management.services;

import java.util.List;

import com.study.management.entities.Question;

public interface QuestionService {
	List<Question> getAllQuestion();
}
