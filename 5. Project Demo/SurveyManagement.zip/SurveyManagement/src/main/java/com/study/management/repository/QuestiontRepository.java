package com.study.management.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.study.management.entities.Question;

public interface QuestiontRepository extends JpaRepository<Question, Integer> {
	final String SELECT_ALL = "SELECT q FROM Question q";

	@Query(SELECT_ALL)
	List<Question> findAllQuestion();
}
