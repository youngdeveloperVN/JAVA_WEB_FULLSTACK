package com.product.management.entities;

public class Category {

}
