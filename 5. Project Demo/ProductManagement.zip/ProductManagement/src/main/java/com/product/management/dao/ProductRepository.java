package com.product.management.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.product.management.entities.Product;

public interface ProductRepository extends JpaRepository<Product, Integer> {
	final String SELECT_ALL = "SELECT p FROM Product p";

	@Query(SELECT_ALL)
	List<Product> findAllProduct();
}
