package com.product.management.services;

import java.util.List;

import com.product.management.entities.Product;

public interface ProductService {
	List<Product> getAllProduct();
}
