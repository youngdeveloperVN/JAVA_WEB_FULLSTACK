package com.product.management.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.product.management.entities.Product;

@Controller
public class ProductController {
	
	@RequestMapping(value = "/product", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public Product getProduct() {
		Product product = new Product();
		product.setName("Huy");
		product.setId("1268");
		return product;
	}
}
