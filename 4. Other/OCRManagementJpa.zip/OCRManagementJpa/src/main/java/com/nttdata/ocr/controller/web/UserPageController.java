package com.nttdata.ocr.controller.web;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.nttdata.ocr.entities.User;
import com.nttdata.ocr.service.UserService;

@Controller
public class UserPageController {

	@Autowired
	private UserService userService;

	@RequestMapping(value = "/users", method = RequestMethod.GET)
	public ModelAndView userPage() {
		ModelAndView m = new ModelAndView("usersPage");
		ArrayList<User> userList = userService.getAll();
		m.addObject("userList", userList);
		return m;
	}
}
