package com.nttdata.ocr.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.nttdata.ocr.beans.IdListBean;
import com.nttdata.ocr.beans.RSAListBean;
import com.nttdata.ocr.beans.StringBean;
import com.nttdata.ocr.entities.User;
import com.nttdata.ocr.service.RSAService;

@RestController
@RequestMapping("/rsa")
public class RSAController {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private RSAService rsaService;

	@RequestMapping(value = "/createKey", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public StringBean createNewKey(HttpServletRequest request, HttpServletResponse response) {
		User superUser = (User)request.getSession().getAttribute("user");
		StringBean bean = new StringBean();
		if (superUser != null ) {
//			bean.setMessage(rsaService.addNewKey(superUser));
			return bean;
		}
		return bean;
	}

	@RequestMapping(value = "/getAllRsaKey", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public RSAListBean getAllRsaKey() {
		RSAListBean list = new RSAListBean();
		list.setList(rsaService.getAll());
		return list;
	}
	
	@RequestMapping(value = "/delete", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public boolean deleteRSAKey(@RequestBody IdListBean idListBean) {
		return rsaService.deleteRSA(idListBean.getList());
	}
	
}