package com.nttdata.ocr.dao;

import java.util.List;

import com.nttdata.ocr.entities.Rsa;
import com.nttdata.ocr.entities.User;

public interface RSADao {
	public String getPrivateKeyByRSAId(String rsaId);

	public boolean createNewKey(User user);

	public List<Rsa> getAll();
	
	public boolean setActive(String userUpdate, String rsaId);
	
	public Rsa getById(String rsaId);

	public boolean remove(String rsaId);

	public List<Rsa> selectRSANonActive();
}
