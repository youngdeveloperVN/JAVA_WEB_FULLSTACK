package com.nttdata.ocr.util;

import java.io.StringReader;
import java.math.BigInteger;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.EncodedKeySpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.RSAPrivateCrtKeySpec;
import java.security.spec.RSAPrivateKeySpec;
import java.security.spec.RSAPublicKeySpec;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import com.nttdata.ocr.common.Constants;
import com.nttdata.ocr.model.RSAKey;
import com.nttdata.ocr.model.RSAKeyString;

public class RSAManager {

	private static RSAManager instance = new RSAManager();

	public static RSAManager getInstance() {
		return instance;
	}

	private PrivateKey privateKey;
	private PublicKey publicKey;

	public PrivateKey getPrivateKey() {
		return privateKey;
	}

	public void setPrivateKey(PrivateKey privateKey) {
		this.privateKey = privateKey;
	}

	public PublicKey getPublicKey() {
		return publicKey;
	}

	public void setPublicKey(PublicKey publicKey) {
		this.publicKey = publicKey;
	}

	public byte[] encrypt(PrivateKey privateKey, String message) throws Exception {
		Cipher cipher = Cipher.getInstance("RSA");
		cipher.init(Cipher.ENCRYPT_MODE, privateKey);
		return cipher.doFinal(message.getBytes());
	}

	public byte[] decrypt(PrivateKey privateKey, byte[] encrypted) throws Exception {
		Cipher cipher = Cipher.getInstance("RSA");
		cipher.init(Cipher.DECRYPT_MODE, privateKey);

		return cipher.doFinal(encrypted);
	}

	public PrivateKey getPrivateKeyFromXmlString(String xmlString) throws Exception {
		PrivateKey privKey = null;
		try {
			RSAKey rsaKeyValue = getKeyFromXmlString(xmlString);
			String modulusElem = rsaKeyValue.getModulus().trim();
			String dElement = rsaKeyValue.getD().trim();

			byte[] modBytes = Base64.getDecoder().decode(modulusElem);
			byte[] dBytes = Base64.getDecoder().decode(dElement);

			BigInteger modules = new BigInteger(1, modBytes);
			BigInteger d = new BigInteger(1, dBytes);

			RSAPrivateKeySpec rsaPrivKey = new RSAPrivateKeySpec(modules, d);
			KeyFactory fact = KeyFactory.getInstance("RSA");
			privKey = fact.generatePrivate(rsaPrivKey);

		} catch (Exception e) {
			e.printStackTrace();
			e.getMessage();
		}
		return privKey;
	}

	public PublicKey getPublicKeyFromXmlString(String xmlString) throws Exception {
		PublicKey publicKey = null;
		try {
			RSAKey rsaKeyValue = getKeyFromXmlString(xmlString);
			String modulusElem = rsaKeyValue.getModulus().trim();
			String exponentElem = rsaKeyValue.getExponent().trim();

			byte[] modBytes = Base64.getDecoder().decode(modulusElem);
			byte[] expBytes = Base64.getDecoder().decode(exponentElem);

			BigInteger modules = new BigInteger(1, modBytes);
			BigInteger exponent = new BigInteger(1, expBytes);

			RSAPublicKeySpec rsaPublicKey = new RSAPublicKeySpec(modules, exponent);
			KeyFactory fact = KeyFactory.getInstance("RSA");
			publicKey = fact.generatePublic(rsaPublicKey);

		} catch (Exception e) {
			e.printStackTrace();
			e.getMessage();
		}
		return publicKey;
	}

	public RSAKey getKeyFromXmlString(String xmlString) {
		RSAKey keyValue = new RSAKey();
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(RSAKey.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();

			StringReader reader = new StringReader(xmlString);
			keyValue = (RSAKey) jaxbUnmarshaller.unmarshal(reader);
		} catch (JAXBException e) {
			e.printStackTrace();
		}
		return keyValue;
	}

	public String decryptPrivateKeyFromXmLString(String xmlString, String encodedString, Charset charsets)
			throws Exception {
		PrivateKey privKey = getPrivateKeyFromXmlString(xmlString);
		return decryptPrivateKey(privKey, encodedString, charsets);
	}

	public String decryptPrivateKey(PrivateKey privateKey, String encodedString, Charset charsets) throws Exception {
		Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
		cipher.init(Cipher.DECRYPT_MODE, privateKey);

		byte[] cipherbytes = Base64.getDecoder().decode(encodedString);
		byte[] plain = cipher.doFinal(cipherbytes);
		String cleartext = new String(plain, charsets);
		return cleartext.trim();
	}

	public String decryptPublicKeyFromXmLString(String xmlString, String encodedString, Charset charsets)
			throws Exception {
		PublicKey publicKey = getPublicKeyFromXmlString(xmlString);
		Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
		cipher.init(Cipher.DECRYPT_MODE, publicKey);

		byte[] cipherbytes = Base64.getDecoder().decode(encodedString);
		byte[] plain = cipher.doFinal(cipherbytes);
		String cleartext = new String(plain, charsets);
		return cleartext;
	}

	public String sign(String plainText, PrivateKey privateKey) throws Exception {
		Signature privateSignature = Signature.getInstance("SHA256withRSA");
		privateSignature.initSign(privateKey);
		privateSignature.update(plainText.getBytes(StandardCharsets.UTF_16LE));

		byte[] signature = privateSignature.sign();

		return Base64.getEncoder().encodeToString(signature);
	}

	public boolean verify(String plainText, String signature, PublicKey publicKey) throws Exception {
		Signature publicSignature = Signature.getInstance("SHA256withRSA");
		publicSignature.initVerify(publicKey);
		publicSignature.update(plainText.getBytes(StandardCharsets.UTF_16LE));

		byte[] signatureBytes = Base64.getDecoder().decode(signature);

		return publicSignature.verify(signatureBytes);
	}

	@SuppressWarnings("unused")
	public RSAKeyString generateKeyString() throws Exception {
		RSAKeyString keyString = new RSAKeyString();
		
		//Generating a Key Pair
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
        keyGen.initialize(Constants.KEY_SIZE);      
        KeyPair keyPair = keyGen.generateKeyPair();
        
        PublicKey publicKey = keyPair.getPublic();
        PrivateKey privateKey = keyPair.getPrivate();

        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        String pvtK = Base64.getEncoder().encodeToString(privateKey.getEncoded());
        EncodedKeySpec privateKeySpec = new PKCS8EncodedKeySpec(Base64.getDecoder().decode(pvtK));
        PrivateKey privateKey2 = keyFactory.generatePrivate(privateKeySpec);
        
		RSAPrivateCrtKeySpec ksPri = keyFactory.getKeySpec(
				privateKey2, RSAPrivateCrtKeySpec.class);
	    String privateXMLString =  "<RSAKeyValue>"+
						    	   "<Modulus>"+ b64encode(removeMSZero(ksPri.getModulus().toByteArray())) + "</Modulus>" +
						    	   "<Exponent>"+  b64encode(removeMSZero(ksPri.getPublicExponent().toByteArray())) +"</Exponent>" +
						    	   "<P>"+ b64encode(removeMSZero(ksPri.getPrimeP().toByteArray())) +"</P>"+
						    	   "<Q>"+ b64encode(removeMSZero(ksPri.getPrimeQ().toByteArray())) +"</Q>"+
						    	   "<DP>"+ b64encode(removeMSZero(ksPri.getPrimeExponentP().toByteArray())) +"</DP>"+
						    	   "<DQ>"+ b64encode(removeMSZero(ksPri.getPrimeExponentQ().toByteArray())) +"</DQ>" + 
						    	   "<InverseQ>"+ b64encode(removeMSZero(ksPri.getCrtCoefficient().toByteArray())) +"</InverseQ>"+
						    	   "<D>"+ b64encode(removeMSZero(ksPri.getPrivateExponent().toByteArray())) +"</D>"+
						    	   "</RSAKeyValue>";        
        keyString.setPrivateKey(privateXMLString);
	    String publicXMLString =  "<RSAKeyValue>"+
						    	   "<Modulus>"+ b64encode(removeMSZero(ksPri.getModulus().toByteArray())) + "</Modulus>" +
						    	   "<Exponent>"+  b64encode(removeMSZero(ksPri.getPublicExponent().toByteArray())) +"</Exponent>" +
//						    	   "<P>"+ b64encode(removeMSZero(ksPri.getPrimeP().toByteArray())) +"</P>"+
//						    	   "<Q>"+ b64encode(removeMSZero(ksPri.getPrimeQ().toByteArray())) +"</Q>"+
//						    	   "<DP>"+ b64encode(removeMSZero(ksPri.getPrimeExponentP().toByteArray())) +"</DP>"+
//						    	   "<DQ>"+ b64encode(removeMSZero(ksPri.getPrimeExponentQ().toByteArray())) +"</DQ>" + 
//						    	   "<InverseQ>"+ b64encode(removeMSZero(ksPri.getCrtCoefficient().toByteArray())) +"</InverseQ>"+
//						    	   "<D>"+ b64encode(removeMSZero(ksPri.getPrivateExponent().toByteArray())) +"</D>"+
						    	   "</RSAKeyValue>"; 
        keyString.setPublicKey(publicXMLString);
		return keyString;
	}
	
	private byte[] removeMSZero(byte[] data) {
		byte[] data1;
		int len = data.length;
		if (data[0] == 0) {
			data1 = new byte[data.length - 1];
			System.arraycopy(data, 1, data1, 0, len - 1);
		} else
			data1 = data;

		return data1;
	}
	
	private final String b64encode(byte[] data) {
		return Base64.getEncoder().encodeToString(data).trim();
	}

}
