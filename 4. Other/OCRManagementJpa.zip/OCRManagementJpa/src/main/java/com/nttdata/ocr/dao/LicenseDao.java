package com.nttdata.ocr.dao;

import java.util.List;

import com.nttdata.ocr.common.GenericDao;
import com.nttdata.ocr.entities.LicenseKey;

public interface LicenseDao extends GenericDao {

	public boolean hasLicenseKey(String licenseKey);
	public String insertLicense(String userId, String customerId, String rsaId, int active, int totalLicense);
	public List<LicenseKey> getAllLicenseKey();
	
	public String findLicenseKey(String rsaID, String licenseKey);
	public boolean updateLicenseString(String licenseString, String licenseKey);
	public String deleteByLicenseKey(String licenseKey);
	public String deleteByCustomerId(String customerId);
	
}