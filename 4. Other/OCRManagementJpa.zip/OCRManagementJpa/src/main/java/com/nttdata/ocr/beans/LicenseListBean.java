package com.nttdata.ocr.beans;

import java.io.Serializable;
import java.util.List;

public class LicenseListBean implements Serializable {

	private static final long serialVersionUID = 1L;
	private List<LicenseKeyVO> list;

	public List<LicenseKeyVO> getList() {
		return list;
	}

	public void setList(List<LicenseKeyVO> list) {
		this.list = list;
	}

}
