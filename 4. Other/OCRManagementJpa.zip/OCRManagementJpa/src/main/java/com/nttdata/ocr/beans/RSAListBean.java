package com.nttdata.ocr.beans;

import java.io.Serializable;
import java.util.List;

import com.nttdata.ocr.entities.Rsa;

public class RSAListBean implements Serializable {

	private static final long serialVersionUID = 1L;
	private List<Rsa> list;

	public List<Rsa> getList() {
		return list;
	}

	public void setList(List<Rsa> list) {
		this.list = list;
	}

}
