package com.nttdata.ocr.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.nttdata.ocr.beans.IdBean;
import com.nttdata.ocr.beans.IdListBean;
import com.nttdata.ocr.beans.UserBean;
import com.nttdata.ocr.beans.UserListBean;
import com.nttdata.ocr.entities.User;
import com.nttdata.ocr.service.UserService;

@RestController
@RequestMapping("/users")
public class UserController {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	 

	@Autowired
	private UserService userService;

	@RequestMapping(value = "/", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public UserListBean getAll() {
		UserListBean list = new UserListBean();
		list.setList(userService.getAll());
		return list;
	}

	@RequestMapping(value = "/{username}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public User getUserByUserName(@PathVariable("username") String username) {
		return userService.getUserByUserName(username);
	}

	@RequestMapping(value = "/add", consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public @ResponseBody boolean creadOrUpdateUser(@RequestBody UserBean userBean, HttpServletRequest request, HttpServletResponse response) {
		User superUser = (User)request.getSession().getAttribute("user");
		if (superUser != null ) {
			return userService.addOrUpdateUser(superUser, userBean);
		}
		return false;
	}
	
	@RequestMapping(value = "/delete", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public boolean deleteCustomerById(@RequestBody IdListBean idListBean) {
		return userService.deleteUserName(idListBean.getList());
	}
	
}