package com.nttdata.ocr.controller.web;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.nttdata.ocr.entities.LicenseKey;
import com.nttdata.ocr.service.LicenseService;

@Controller
public class LicensePageController {

	@Autowired
	private LicenseService licenseService;
	
	@RequestMapping(value = "/licenses", method = RequestMethod.GET)
	public ModelAndView licensesPage() {
		ModelAndView m = new ModelAndView("licensePage");
		ArrayList<LicenseKey> licenseList = (ArrayList<LicenseKey>)licenseService.getAllLicenseKey();
		m.addObject("licenseList", licenseList);
		return m;
	}
}
