package com.nttdata.ocr.beans;

import java.io.Serializable;
import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * The persistent class for the license_key database table.
 * 
 */
public class LicenseKeyVO implements Serializable {
	private static final long serialVersionUID = 1L;

	private String licenseKey;
	private Timestamp activedDate;
	private Timestamp createDate;
	private String createUser;

	private String customerName;
	private String customerID;
	private Timestamp effectivedDate;
	private Timestamp innitiatedDate;

	@JsonProperty("isActived")
	private Integer isActived;
	private Timestamp lastModifiedDate;
	private String lastModifiedUser;
	private String licenseString;
	private Integer licenseType;
	private String rsaID;
	private Integer status;

	public String getLicenseKey() {
		return this.licenseKey;
	}

	public void setLicenseKey(String licenseKey) {
		this.licenseKey = licenseKey;
	}

	public Timestamp getActivedDate() {
		return this.activedDate;
	}

	public void setActivedDate(Timestamp activedDate) {
		this.activedDate = activedDate;
	}

	public Timestamp getCreateDate() {
		return this.createDate;
	}

	public void setCreateDate(Timestamp createDate) {
		this.createDate = createDate;
	}

	public String getCreateUser() {
		return this.createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public String getCustomerId() {
		return this.customerID;
	}

	public void setCustomerId(String customerID) {
		this.customerID = customerID;
	}

	public Timestamp getEffectivedDate() {
		return this.effectivedDate;
	}

	public void setEffectivedDate(Timestamp effectivedDate) {
		this.effectivedDate = effectivedDate;
	}

	public Timestamp getInnitiatedDate() {
		return this.innitiatedDate;
	}

	public void setInnitiatedDate(Timestamp innitiatedDate) {
		this.innitiatedDate = innitiatedDate;
	}

	public Integer getIsActived() {
		return this.isActived;
	}

	public void setIsActived(Integer isActived) {
		this.isActived = isActived;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getLastModifiedUser() {
		return this.lastModifiedUser;
	}

	public void setLastModifiedUser(String lastModifiedUser) {
		this.lastModifiedUser = lastModifiedUser;
	}

	public String getLicenseString() {
		return this.licenseString;
	}

	public void setLicenseString(String licenseString) {
		this.licenseString = licenseString;
	}

	public Integer getLicenseType() {
		return this.licenseType;
	}

	public void setLicenseType(Integer licenseType) {
		this.licenseType = licenseType;
	}

	public String getRsaID() {
		return this.rsaID;
	}

	public void setRsaID(String rsaID) {
		this.rsaID = rsaID;
	}

	public Integer getStatus() {
		return this.status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

}