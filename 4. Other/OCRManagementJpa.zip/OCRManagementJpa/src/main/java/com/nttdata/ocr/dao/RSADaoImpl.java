package com.nttdata.ocr.dao;

import java.util.List;

import javax.persistence.PersistenceException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.nttdata.ocr.common.Constants;
import com.nttdata.ocr.entities.Rsa;
import com.nttdata.ocr.entities.User;
import com.nttdata.ocr.model.RSAKeyString;
import com.nttdata.ocr.repositories.LicenseKeyRepository;
import com.nttdata.ocr.repositories.RsaRepository;
import com.nttdata.ocr.util.DateHelper;
import com.nttdata.ocr.util.GeneratorID;
import com.nttdata.ocr.util.RSAManager;

@Component
public class RSADaoImpl implements RSADao {

	@Autowired
	private RsaRepository rsaRepository;
	
	@Autowired
	private LicenseKeyRepository licenseKeyRepository;

	@Override
	public String getPrivateKeyByRSAId(String rsaId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean setActive(String userUpdate, String rsaId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Rsa getById(String rsaId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean remove(String rsaId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Rsa> selectRSANonActive() {
		// TODO Auto-generated method stub
		return null;
	}

//	@Override
//	public String getPrivateKeyByRSAId(String rsaId) {
//		String privateKey = "";
//		try {
//			privateKey = rsaMapper.findPrivateKeyByRSAId(rsaId);
//		} catch (PersistenceException e) {
//			throw e;
//		} catch (Exception ex) {
//			throw ex;
//		}
//		return privateKey;
//	}
//
	@Override
	public boolean createNewKey(User user) {
		try {
			RSAKeyString keyString = RSAManager.getInstance().generateKeyString();
			
			Rsa rsaItem = new Rsa();
			
			//create 
			rsaItem.setRsaId(GeneratorID.createId(Constants.KEY_ID_RSA));
			rsaItem.setPrivateKey(keyString.getPrivateKey()); 
			rsaItem.setPublicKey(keyString.getPublicKey());
			rsaItem.setIsActived(Constants.KEY_ACTIVE);
			
			rsaItem.setCreateDate(DateHelper.now());
			rsaItem.setLastModifiedDate(DateHelper.now());
			
			rsaItem.setCreateUser(user.getUserName());
			rsaItem.setLastModifiedUser(user.getUserName());
			rsaRepository.save(rsaItem);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
//
	@Override
	public List<Rsa> getAll() {
		try {
			return rsaRepository.findAll();
		} catch (Exception e) {
			throw e;
		}
	}
//
//	@Override
//	public boolean setActive(String userUpdate, String rsaId) {
//		try {
//			Rsa rsaItem = getById(rsaId);
//			rsaItem.setIsActived(Constants.KEY_ACTIVE);
//			rsaItem.setLastModifiedUser(userUpdate);
//			rsaItem.setLastModifiedDate(DateHelper.now());
//			rsaMapper.setActiveRSA(rsaItem);
//			return true;
//		} catch (PersistenceException e) {
//			e.printStackTrace();
//			throw e;
//		}
//	}
//
//	@Override
//	public Rsa getById(String rsaId) {
//		try {
//			return rsaMapper.getById(rsaId);
//		} catch (Exception e) {
//			// TODO: handle exception
//		}
//		return null;
//	}
//
//	@Override
//	public boolean remove(String rsaId) {
//		try {
//			int license = licenseMapper.countLicenseByRSAId(rsaId);
//			if(license < 1) {
//				rsaMapper.deleteById(rsaId);
//				return true;
//			} else return false;
//		} catch (Exception e) {
//			// TODO: handle exception
//		}
//		return false;
//	}
//
//	@Override
//	public List<Rsa> selectRSANonActive() {
//		try {
//			return rsaMapper.selectRSANonActive();
//		} catch (PersistenceException e) {
//			// TODO: handle exception
//			e.printStackTrace();
//			throw e;
//		}
//	}

}
