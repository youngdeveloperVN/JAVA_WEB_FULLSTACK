//package com.nttdata.ocr.config;
//
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//import org.springframework.web.method.HandlerMethod;
//import org.springframework.web.servlet.ModelAndView;
//import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;
//
//public class LoginInterceptor extends HandlerInterceptorAdapter {
//	@Override
//	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
//			throws Exception {
//
//		String controllerName = "";
//		String actionName = "";
//		boolean isExistSession = false;
//
//		if (handler instanceof HandlerMethod) {
//
//			HandlerMethod handlerMethod = (HandlerMethod) handler;
//
//			controllerName = handlerMethod.getBeanType().getSimpleName().replace("Controller", "");
//
//			actionName = handlerMethod.getMethod().getName();
//
//			isExistSession = request.getSession().getAttribute("user") != null;
//		}
//		if(controllerName.equals("License") && actionName.equals("verifyLicenseKey")) return true;
//		if (controllerName.equals("Login") && (actionName.equals("initLogin") || actionName.equals("checkLogin"))) {
//			return true;
//		} else if (!controllerName.equals("") && !actionName.equals("") && (!isExistSession)) {
//			response.sendRedirect(request.getContextPath() + "/index");
//			return false;
//		} 
//		return true;
//	}
//
//	@Override
//	public void postHandle(HttpServletRequest req, HttpServletResponse res, Object handler, ModelAndView model)
//			throws Exception {
//
//		// To do
//	}
//
//	@Override
//	public void afterCompletion(HttpServletRequest req, HttpServletResponse res, Object handler, Exception ex)
//			throws Exception {
//
//		// To do
//	}
//
//}
