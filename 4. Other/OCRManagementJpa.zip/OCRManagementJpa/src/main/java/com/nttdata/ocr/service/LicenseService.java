package com.nttdata.ocr.service;

import java.util.List;

import com.nttdata.ocr.beans.IdBean;
import com.nttdata.ocr.beans.LicenseCustomerBean;
import com.nttdata.ocr.beans.StringBean;
import com.nttdata.ocr.beans.StringList;
import com.nttdata.ocr.common.GenericService;
import com.nttdata.ocr.entities.LicenseKey;
import com.nttdata.ocr.entities.User;
import com.nttdata.ocr.model.PCRequestActive;

public interface LicenseService extends GenericService {
	public String decPrivateKey(byte[] encrypted) throws Exception;
	
	public String verifyRequestActive(PCRequestActive requestActive);
	
	public StringList createOrUpdateLicenseKey(User user, LicenseCustomerBean licenseCustomer);
	
	public List<LicenseKey> getAllLicenseKey();

	public StringBean deleteByLicenseKey(List<IdBean> listLicenseKey);

	public String deleteByCustomerId(String customerId);

}
