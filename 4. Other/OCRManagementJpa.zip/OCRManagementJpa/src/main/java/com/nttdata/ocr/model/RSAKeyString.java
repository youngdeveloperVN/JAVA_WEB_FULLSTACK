package com.nttdata.ocr.model;

import java.io.Serializable;

public class RSAKeyString implements Serializable {

	private static final long serialVersionUID = 1L;
	private String privateKey;
	private String publicKey;

	public String getPrivateKey() {
		return privateKey;
	}

	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}

	public String getPublicKey() {
		return publicKey;
	}

	public void setPublicKey(String publicKey) {
		this.publicKey = publicKey;
	}

}
