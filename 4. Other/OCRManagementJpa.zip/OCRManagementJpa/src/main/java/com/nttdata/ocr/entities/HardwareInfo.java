package com.nttdata.ocr.entities;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;


/**
 * The persistent class for the hardware_info database table.
 * 
 */
@Entity
@Table(name="hardware_info")
@NamedQuery(name="HardwareInfo.findAll", query="SELECT h FROM HardwareInfo h")
public class HardwareInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="license_key")
	private String licenseKey;

	@Column(name="create_date")
	private Timestamp createDate;

	@Column(name="create_user")
	private String createUser;

	@Column(name="hard_disk_serial")
	private String hardDiskSerial;

	@Column(name="ip_address")
	private String ipAddress;

	@Column(name="last_modified_date")
	private Timestamp lastModifiedDate;

	@Column(name="last_modified_user")
	private String lastModifiedUser;

	@Column(name="mac_address")
	private String macAddress;

	@Column(name="main_serial")
	private String mainSerial;

	//bi-directional one-to-one association to LicenseKey
	@OneToOne(mappedBy="hardwareInfo")
	private LicenseKey licenseKeyBean;

	public HardwareInfo() {
	}

	public String getLicenseKey() {
		return this.licenseKey;
	}

	public void setLicenseKey(String licenseKey) {
		this.licenseKey = licenseKey;
	}

	public Timestamp getCreateDate() {
		return this.createDate;
	}

	public void setCreateDate(Timestamp createDate) {
		this.createDate = createDate;
	}

	public String getCreateUser() {
		return this.createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public String getHardDiskSerial() {
		return this.hardDiskSerial;
	}

	public void setHardDiskSerial(String hardDiskSerial) {
		this.hardDiskSerial = hardDiskSerial;
	}

	public String getIpAddress() {
		return this.ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getLastModifiedUser() {
		return this.lastModifiedUser;
	}

	public void setLastModifiedUser(String lastModifiedUser) {
		this.lastModifiedUser = lastModifiedUser;
	}

	public String getMacAddress() {
		return this.macAddress;
	}

	public void setMacAddress(String macAddress) {
		this.macAddress = macAddress;
	}

	public String getMainSerial() {
		return this.mainSerial;
	}

	public void setMainSerial(String mainSerial) {
		this.mainSerial = mainSerial;
	}

	public LicenseKey getLicenseKeyBean() {
		return this.licenseKeyBean;
	}

	public void setLicenseKeyBean(LicenseKey licenseKeyBean) {
		this.licenseKeyBean = licenseKeyBean;
	}

}