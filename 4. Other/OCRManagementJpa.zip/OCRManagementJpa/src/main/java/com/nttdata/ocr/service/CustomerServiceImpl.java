package com.nttdata.ocr.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.nttdata.ocr.beans.CustomerBean;
import com.nttdata.ocr.beans.IdBean;
import com.nttdata.ocr.dao.CustomerDao;
import com.nttdata.ocr.entities.Customer;
import com.nttdata.ocr.entities.User;
import com.nttdata.ocr.util.DateHelper;
import com.nttdata.ocr.util.GeneratorID;

@Component
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerDao customerDao;

	@Override
	public boolean addOrUpdateCustomer(CustomerBean customerBean, User user) {
		try {
			Customer customerDB = customerDao.findCustomerById(customerBean.getCustomerId());
			if (customerDB == null) {
				customerDB = convertBeanToEntity(customerBean);
				customerDB.setCustomerId(GeneratorID.createId(customerBean.getCustomerName()));
				customerDB.setCreateUser(user.getUserName());
				customerDB.setCreateDate(DateHelper.now());
				customerDB.setLastModifiedDate(DateHelper.now());
				customerDB.setLastModifiedUser(user.getUserName());
				customerDB.setLastModifiedDate(DateHelper.now());
				
				return customerDao.insertCustomer(customerDB);
				
			} else {
				customerDB = convertBeanToEntity(customerBean);
				customerDB.setCustomerId(customerBean.getCustomerId());
				customerDB.setLastModifiedDate(DateHelper.now());
				customerDB.setLastModifiedUser(user.getUserName());
				
				return customerDao.updateCustomer(customerDB);
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return false;
	
	}

	@Override
	public boolean removeCustomer(List<IdBean> beans) {
		for (int i = 0; i < beans.size(); i++) {
			if (beans.get(i) != null && beans.get(i).getId() != null) {
				Customer customer = customerDao.findCustomerById(beans.get(i).getId());
				if (customer != null) {
					customerDao.deleteCustomerById(customer.getCustomerId());
				}
			}
		}
		return true;
	}

	@Override
	public CustomerBean getCustomerById(String customerId) {
		Customer customer = customerDao.findCustomerById(customerId);
		if (customer != null) {
			return convertEntityToBean(customer);
		}
		return new CustomerBean();
	}

	@Override
	public List<Customer> getAllCustomer() {
		// TODO Auto-generated method stub
		return customerDao.findAllCustomer();
	}

	//create customer for create
	private Customer convertBeanToEntity(CustomerBean bean) {
		Customer customer = new Customer();
		customer.setAddress(bean.getAddress());
		customer.setContractNumber(bean.getContractNumber());
		customer.setCustomerName(bean.getCustomerName());
		customer.setEmail(bean.getEmail());
		customer.setPhoneNumber(bean.getPhoneNumber());
		customer.setIsActived(boolToInt(bean.isActived()));

		// add new variable (column requite)
		// TODO
		return customer;
	}

	private CustomerBean convertEntityToBean(Customer bean) {
		CustomerBean customer = new CustomerBean();

		customer.setCustomerId(bean.getCustomerId());
		customer.setAddress(bean.getAddress());
		customer.setContractNumber(bean.getContractNumber());
		customer.setCustomerName(bean.getCustomerName());
		customer.setEmail(bean.getEmail());
		customer.setPhoneNumber(bean.getPhoneNumber());
		customer.setActived(intToboolean(bean.getIsActived()));
		return customer;
	}

}
