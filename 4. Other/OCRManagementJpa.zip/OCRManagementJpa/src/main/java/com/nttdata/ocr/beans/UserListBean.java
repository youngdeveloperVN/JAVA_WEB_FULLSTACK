package com.nttdata.ocr.beans;

import java.io.Serializable;
import java.util.ArrayList;

import com.nttdata.ocr.entities.User;

public class UserListBean implements Serializable {

	private static final long serialVersionUID = 3758914117908246344L;
	private ArrayList<User> list;

	public ArrayList<User> getList() {
		return list;
	}

	public void setList(ArrayList<User> list) {
		this.list = list;
	}
}
