package com.nttdata.ocr.common;

public interface GenericDao {

}
