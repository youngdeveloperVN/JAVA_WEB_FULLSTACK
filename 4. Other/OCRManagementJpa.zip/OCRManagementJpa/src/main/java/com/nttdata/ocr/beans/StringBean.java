package com.nttdata.ocr.beans;

import java.io.Serializable;

public class StringBean implements Serializable{

	private static final long serialVersionUID = -1132478558131367960L;
	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
}
