package com.nttdata.ocr.beans;

import java.io.Serializable;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;

public class UserBean implements Serializable {
	
	private static final long serialVersionUID = 1L;
	@NotNull
    @Size(min=5, max=50)
	private String username;
//	private Timestamp createDate;
//	private String createUser;
	private String fullName;
	
	@JsonProperty("isActived")
	private boolean isActived;
//	private Timestamp lastModifiedDate;
//	private String lastModifiedUser;
	@NotNull
    @Size(min=5, max=50)
	private String password;
	private Integer role;
	
	public String getUserName() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

//	public Timestamp getCreateDate() {
//		return createDate;
//	}
//
//	public void setCreateDate(Timestamp createDate) {
//		this.createDate = createDate;
//	}

//	public String getCreateUser() {
//		return createUser;
//	}
//
//	public void setCreateUser(String createUser) {
//		this.createUser = createUser;
//	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

//	public Integer getIsActived() {
//		return isActived;
//	}
//
//	public void setIsActived(Integer isActived) {
//		this.isActived = isActived;
//	}

//	public Timestamp getLastModifiedDate() {
//		return lastModifiedDate;
//	}
//
//	public void setLastModifiedDate(Timestamp lastModifiedDate) {
//		this.lastModifiedDate = lastModifiedDate;
//	}

//	public String getLastModifiedUser() {
//		return lastModifiedUser;
//	}
//
//	public void setLastModifiedUser(String lastModifiedUser) {
//		this.lastModifiedUser = lastModifiedUser;
//	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Integer getRole() {
		return role;
	}

	public void setRole(Integer role) {
		this.role = role;
	}

	public boolean isActived() {
		return isActived;
	}

	public void setActived(boolean isActived) {
		this.isActived = isActived;
	}

}