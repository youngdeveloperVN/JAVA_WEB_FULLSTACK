package com.nttdata.ocr.common;

import org.springframework.beans.factory.annotation.Value;

public class Constants {
	public static final String KEY_ID_RSA = "R S A";
	public static int KEY_SIZE = 4096;
	
	public static final String FORMAT_DATE = "dd-MM-yyyy HH:mm:ss.SSS";
	
	
	@Value("${server.contextPath}")
	public static String ROOT;
	
	public static String CUSTOMER_PAGE = ROOT + "/customer";
	public static String KEY_SESSION_USER = "user";
	public static final Integer KEY_ACTIVE = 1;
	public static final Integer KEY_DISABLE_ACTIVE = 0;
	
	
}

