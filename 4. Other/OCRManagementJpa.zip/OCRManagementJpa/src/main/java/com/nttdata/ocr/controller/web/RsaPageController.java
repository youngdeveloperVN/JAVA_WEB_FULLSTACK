package com.nttdata.ocr.controller.web;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.nttdata.ocr.beans.IdListBean;
import com.nttdata.ocr.entities.Rsa;
import com.nttdata.ocr.entities.User;
import com.nttdata.ocr.service.RSAService;

@Controller

public class RsaPageController {

	@Autowired
	private RSAService rsaService;

	@RequestMapping(value = "/rsakey", method = RequestMethod.GET)
	public ModelAndView rsaPage() {
		ModelAndView m = new ModelAndView("rsaPage");
		ArrayList<Rsa> rsaList = (ArrayList<Rsa>) rsaService.getAll();
		m.addObject("rsaList", rsaList);
		return m;
	}
	
	@RequestMapping(value = "/rsakey/create", method = RequestMethod.POST)
	public String createNewKey(HttpServletRequest request, HttpServletResponse response) {
		User superUser = (User)request.getSession().getAttribute("user");
		rsaService.addNewKey(superUser);
		return "redirect:/rsakey";

	}

	@RequestMapping(value = "/rsakey/delete", method = RequestMethod.POST)
	public String deleteRSAKey(@RequestBody IdListBean idListBean) {
		rsaService.deleteRSA(idListBean.getList());
		return "redirect:/rsakey";
	}
	
}
