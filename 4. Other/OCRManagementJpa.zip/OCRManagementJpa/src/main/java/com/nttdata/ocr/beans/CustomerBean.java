package com.nttdata.ocr.beans;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CustomerBean implements Serializable {

	private static final long serialVersionUID = 1L;
	private String customerID;
	private String address;
	private String contractNumber;
	// private Timestamp createDate;
	// private String createUser;
	private String customerName;
	private String email;

	@JsonProperty("isActived")
	private boolean isActived;
	// private Timestamp lastModifiedDate;
	// private String lastModifiedUser;
	private String phoneNumber;
	
//	private List<LicenseKey> licenseKey = null;

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getContractNumber() {
		return contractNumber;
	}

	public void setContractNumber(String contractNumber) {
		this.contractNumber = contractNumber;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public boolean isActived() {
		return isActived;
	}

	public void setActived(boolean isActived) {
		this.isActived = isActived;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getCustomerId() {
		return customerID;
	}

	public void setCustomerId(String customerID) {
		this.customerID = customerID;
	}

}
