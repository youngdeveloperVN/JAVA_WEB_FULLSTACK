package com.nttdata.ocr.util;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.nttdata.ocr.common.Constants;

public class DateHelper {

	public static Timestamp now() {
		return new Timestamp(new Date().getTime());
	}
	
	public static String nowToString() {
		SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.FORMAT_DATE);
		// remove space, - , :
		return dateFormat.format(new Date()).replace("-", "").replace(".", "").replace(":", "").replaceAll("\\s+", "");
	}
	
}