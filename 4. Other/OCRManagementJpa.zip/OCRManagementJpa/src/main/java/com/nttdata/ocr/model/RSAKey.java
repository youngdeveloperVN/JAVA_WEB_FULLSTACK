package com.nttdata.ocr.model;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="RSAKeyValue")
public class RSAKey {

	private String Modulus;
	private String Exponent;
	private String P;
	private String Q;
	private String DP;
	private String DQ;
	private String InverseQ;
	private String D;

	public String getModulus() {
		return Modulus;
	}

	@XmlElement(name="Modulus")
	public void setModulus(String modulus) {
		Modulus = modulus;
	}

	public String getExponent() {
		return Exponent;
	}

	@XmlElement(name="Exponent")
	public void setExponent(String exponent) {
		Exponent = exponent;
	}

	public String getP() {
		return P;
	}

	@XmlElement(name="P")
	public void setP(String p) {
		P = p;
	}

	public String getQ() {
		return Q;
	}

	@XmlElement(name="Q")
	public void setQ(String q) {
		Q = q;
	}

	public String getDP() {
		return DP;
	}

	@XmlElement(name="DP")
	public void setDP(String dP) {
		DP = dP;
	}

	public String getDQ() {
		return DQ;
	}

	@XmlElement(name="DQ")
	public void setDQ(String dQ) {
		DQ = dQ;
	}

	public String getInverseQ() {
		return InverseQ;
	}

	@XmlElement(name="InverseQ")
	public void setInverseQ(String inverseQ) {
		InverseQ = inverseQ;
	}

	public String getD() {
		return D;
	}

	@XmlElement(name="D")
	public void setD(String d) {
		D = d;
	}

}