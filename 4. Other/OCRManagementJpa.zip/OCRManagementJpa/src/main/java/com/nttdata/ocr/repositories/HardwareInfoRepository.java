package com.nttdata.ocr.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nttdata.ocr.entities.HardwareInfo;

@Repository
public interface HardwareInfoRepository extends JpaRepository<HardwareInfo, Long> {
}