package com.nttdata.ocr.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.nttdata.ocr.beans.IdBean;
import com.nttdata.ocr.beans.UserBean;
import com.nttdata.ocr.entities.User;

@Service
public interface UserService {

	public ArrayList<User> getAll();

	public User getUserByUserName(String username);

	public boolean addOrUpdateUser(User superUser, UserBean userBean);

	public boolean deleteUserName(List<IdBean> list);

	public User findUserByUserNameAndPass(String username, String password);
	
	public User findUserByEmail(String email);
	
	public void saveUser(User user);

}
