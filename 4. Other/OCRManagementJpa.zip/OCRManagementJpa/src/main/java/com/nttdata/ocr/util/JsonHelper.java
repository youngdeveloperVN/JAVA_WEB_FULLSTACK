package com.nttdata.ocr.util;

import com.google.gson.Gson;

public class JsonHelper {
	public static <T> T fromJson(String json, Class<T> classOfT) {
		try {
			Gson gson = new Gson();
			return gson.fromJson(json, classOfT);
		} catch (Exception e) {
			// TODO: handle exception
			throw e;
		}

	}

	public static String toJson(Object obj) {
		Gson gson = new Gson();
		return gson.toJson(obj);
	}
}
