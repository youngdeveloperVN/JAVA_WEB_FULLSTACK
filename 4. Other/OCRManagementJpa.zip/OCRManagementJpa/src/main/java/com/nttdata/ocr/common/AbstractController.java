package com.nttdata.ocr.common;
//package com.nttdata.ocr.common;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//public abstract class AbstractController {
//	private final Logger logger = LoggerFactory.getLogger(this.getClass());
//
//	public Logger getLogger() {
//		return logger;
//	}
//}
