package com.nttdata.ocr.beans;

import java.io.Serializable;
import java.util.List;

import com.nttdata.ocr.entities.Customer;

public class CustomerListBean implements Serializable {

	private static final long serialVersionUID = 1L;
	private List<Customer> list;

	public List<Customer> getList() {
		return list;
	}

	public void setList(List<Customer> list) {
		this.list = list;
	}

}