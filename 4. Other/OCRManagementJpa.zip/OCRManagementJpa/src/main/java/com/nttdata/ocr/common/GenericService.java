package com.nttdata.ocr.common;

public interface GenericService {
	

	// 1 = true
	// 0 = false
	default int boolToInt(boolean bool) {
		if (!bool)
			return 0;
		else
			return 1;
	}

	// for active
	default boolean intToboolean(int active) {
		if (active == 0)
			return false;
		else
			return true;
	}

}
