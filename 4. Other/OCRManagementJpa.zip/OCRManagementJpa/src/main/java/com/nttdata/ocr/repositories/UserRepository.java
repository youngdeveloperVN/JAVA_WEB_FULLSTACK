package com.nttdata.ocr.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.nttdata.ocr.entities.User;

@Repository
public interface UserRepository extends JpaRepository<User, String> {
	
	final String SELECT_ALL = "SELECT u FROM User u ORDER BY u.createDate DESC";
	final String SELECT_BY_LOGIN = "SELECT u FROM User u WHERE u.userName = :userName and u.password = :password";
	final String SELECT_BY_EMAIL = "SELECT u FROM User u WHERE u.email = :email";

	@Query(SELECT_ALL)
	List<User> findAll();

	@Query(SELECT_BY_LOGIN)
	User findUserByUserNameAndPass(@Param("userName") String userName, @Param("password") String password);
	
	@Query(SELECT_BY_LOGIN)
	User findByEmail(@Param("") String email);
	
}