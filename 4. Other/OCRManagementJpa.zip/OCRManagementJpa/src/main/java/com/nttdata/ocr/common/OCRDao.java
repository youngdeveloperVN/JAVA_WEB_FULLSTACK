package com.nttdata.ocr.common;

public interface OCRDao {

}
