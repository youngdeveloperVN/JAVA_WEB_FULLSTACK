package com.nttdata.ocr.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.nttdata.ocr.entities.Rsa;

@Repository
public interface RsaRepository extends JpaRepository<Rsa, String> {

	final String SELECT_ALL = "SELECT r FROM Rsa r ORDER BY r.createDate DESC";

	@Query(SELECT_ALL)
	List<Rsa> findAll();
}