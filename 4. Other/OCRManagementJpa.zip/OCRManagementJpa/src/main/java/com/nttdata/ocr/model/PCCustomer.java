
package com.nttdata.ocr.model;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PCCustomer implements Serializable {

	@SerializedName("InformationMachine")
	@Expose
	public InformationMachine informationMachine;
	@SerializedName("LicenseKey")
	@Expose
	public String licenseKey;
	private final static long serialVersionUID = 1L;

	public InformationMachine getInformationMachine() {
		return informationMachine;
	}

	public void setInformationMachine(InformationMachine informationMachine) {
		this.informationMachine = informationMachine;
	}

	public String getLicenseKey() {
		return licenseKey;
	}

	public void setLicenseKey(String licenseKey) {
		this.licenseKey = licenseKey;
	}

}