package com.nttdata.ocr.controller.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomePageController {

	@RequestMapping("/")
	public ModelAndView index() {
		ModelAndView m = new ModelAndView("homePage");
		return m;
	}

	@RequestMapping("/home")
	public ModelAndView home() {
		ModelAndView m = new ModelAndView("homePage");
		return m;
	}

}