package com.nttdata.ocr.entities;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;


/**
 * The persistent class for the license_key database table.
 * 
 */
@Entity
@Table(name="license_key")
@NamedQuery(name="LicenseKey.findAll", query="SELECT l FROM LicenseKey l")
public class LicenseKey implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="license_key")
	private String licenseKey;

	@Column(name="actived_date")
	private Timestamp activedDate;

	@Column(name="create_date")
	private Timestamp createDate;

	@Column(name="create_user")
	private String createUser;

	@Column(name="effectived_date")
	private Timestamp effectivedDate;

	@Column(name="innitiated_date")
	private Timestamp innitiatedDate;

	@Column(name="is_actived")
	private Integer isActived;

	@Column(name="last_modified_date")
	private Timestamp lastModifiedDate;

	@Column(name="last_modified_user")
	private String lastModifiedUser;

	@Column(name="license_string")
	private String licenseString;

	@Column(name="license_type")
	private Integer licenseType;

	private Integer status;

	//bi-directional many-to-one association to Customer
	@ManyToOne
	@JoinColumn(name="customer_id")
	private Customer customer;

	//bi-directional one-to-one association to HardwareInfo
	@OneToOne
	@JoinColumn(name="license_key")
	private HardwareInfo hardwareInfo;

	//bi-directional many-to-one association to Rsa
	@ManyToOne
	@JoinColumn(name="rsa_id")
	private Rsa rsa;

	public LicenseKey() {
	}

	public String getLicenseKey() {
		return this.licenseKey;
	}

	public void setLicenseKey(String licenseKey) {
		this.licenseKey = licenseKey;
	}

	public Timestamp getActivedDate() {
		return this.activedDate;
	}

	public void setActivedDate(Timestamp activedDate) {
		this.activedDate = activedDate;
	}

	public Timestamp getCreateDate() {
		return this.createDate;
	}

	public void setCreateDate(Timestamp createDate) {
		this.createDate = createDate;
	}

	public String getCreateUser() {
		return this.createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public Timestamp getEffectivedDate() {
		return this.effectivedDate;
	}

	public void setEffectivedDate(Timestamp effectivedDate) {
		this.effectivedDate = effectivedDate;
	}

	public Timestamp getInnitiatedDate() {
		return this.innitiatedDate;
	}

	public void setInnitiatedDate(Timestamp innitiatedDate) {
		this.innitiatedDate = innitiatedDate;
	}

	public Integer getIsActived() {
		return this.isActived;
	}

	public void setIsActived(Integer isActived) {
		this.isActived = isActived;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getLastModifiedUser() {
		return this.lastModifiedUser;
	}

	public void setLastModifiedUser(String lastModifiedUser) {
		this.lastModifiedUser = lastModifiedUser;
	}

	public String getLicenseString() {
		return this.licenseString;
	}

	public void setLicenseString(String licenseString) {
		this.licenseString = licenseString;
	}

	public Integer getLicenseType() {
		return this.licenseType;
	}

	public void setLicenseType(Integer licenseType) {
		this.licenseType = licenseType;
	}

	public Integer getStatus() {
		return this.status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Customer getCustomer() {
		return this.customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public HardwareInfo getHardwareInfo() {
		return this.hardwareInfo;
	}

	public void setHardwareInfo(HardwareInfo hardwareInfo) {
		this.hardwareInfo = hardwareInfo;
	}

	public Rsa getRsa() {
		return this.rsa;
	}

	public void setRsa(Rsa rsa) {
		this.rsa = rsa;
	}

}