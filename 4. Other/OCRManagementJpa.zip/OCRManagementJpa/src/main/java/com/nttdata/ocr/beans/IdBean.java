package com.nttdata.ocr.beans;

import java.io.Serializable;

public class IdBean implements Serializable {
	
	private static final long serialVersionUID = 1L;
	String id = "";

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

}
