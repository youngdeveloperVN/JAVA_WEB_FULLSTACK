package com.nttdata.ocr.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.nttdata.ocr.entities.LicenseKey;
import com.nttdata.ocr.repositories.LicenseKeyRepository;

@Component
public class LicenseDaoImpl implements LicenseDao {

	@Autowired
	private LicenseKeyRepository licenseKeyRepository;

	@Override
	public boolean hasLicenseKey(String licenseKey) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String insertLicense(String userId, String customerId, String rsaId, int active, int totalLicense) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String findLicenseKey(String rsaID, String licenseKey) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updateLicenseString(String licenseString, String licenseKey) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String deleteByLicenseKey(String licenseKey) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteByCustomerId(String customerId) {
		// TODO Auto-generated method stub
		return null;
	}
	
//	@Override
//	public boolean hasLicenseKey(String licenseKey) {
//		try {
//			int hasLicense = licenseMapper.checkLicense(licenseKey);
//			if (hasLicense > 0 ) {
//				return true;
//			}
//		} catch (PersistenceException e) {
//			// TODO: handle exception
//			e.printStackTrace();
//		}
//		return false;
//	}
//
//	@Override
//	public boolean updateLicenseString(String licenseString, String licenseKey) {
//		// TODO Auto-generated method stub
//		try {
//			if (StringUtils.isNotEmpty(licenseKey)) {
//				licenseMapper.updateLicenseStringByLicenseKey(licenseString, licenseKey);
//				return true;
//			}
//		} catch (Exception e) {
//			// TODO: handle exception
//			e.printStackTrace();
//		}
//		return false;
//	}
//
//	@Override
//	public String insertLicense(String userId, String customerId, String rsaId, int active, int index) {
//		String licenseKey = null;
//		try {
//			LicenseKey license = new LicenseKey();
//			licenseKey = LicenseKeyHelper.getInstance().createLicenserKey(rsaId + DateHelper.nowToString() + index);
//			license.setLicenseKey(licenseKey);
//			license.setRsaID(rsaId);
//			license.setCustomerId(customerId);
//			license.setIsActived(active);
//			license.setStatus(active);
//			license.setInnitiatedDate(DateHelper.now());
//			license.setCreateUser(userId);
//			license.setCreateDate(DateHelper.now());
//			license.setLastModifiedDate(DateHelper.now());
//			license.setLastModifiedUser(userId);
//			licenseMapper.insertLicense(license);
//		} catch (NoSuchAlgorithmException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		return licenseKey;
//	}
//
	@Override
	public List<LicenseKey> getAllLicenseKey() {
		try {
			return licenseKeyRepository.findAll();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
//	
//	@Override
//	public String findLicenseKey(String rsaID, String licenseKey) {
//		try {
//			return licenseMapper.findKeyByAndRsaId(rsaID, licenseKey);
//		} catch (PersistenceException e) {
//			e.printStackTrace();
//			throw e;
//		}
//	}
//
//	@Override
//	public String deleteByLicenseKey(String licenseKey) {
//		try {
//			licenseMapper.deleteByLicenseKey(licenseKey);
//			return licenseKey;
//		} catch (PersistenceException e) {
//			// TODO: handle exception
//			e.printStackTrace();
//		}
//		return null;
//	}
//
//	@Override
//	public String deleteByCustomerId(String customerId) {
//		try {
//			licenseMapper.deleteByCustomerId(customerId);
//			return customerId;
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return null;
//	}
}
