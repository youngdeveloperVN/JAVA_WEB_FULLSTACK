package com.nttdata.ocr.OCRManagementJpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OcrManagementJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(OcrManagementJpaApplication.class, args);
	}
}
