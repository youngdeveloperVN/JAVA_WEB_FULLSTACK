package com.nttdata.ocr.controller.web;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.nttdata.ocr.beans.IdBean;
import com.nttdata.ocr.entities.Customer;
import com.nttdata.ocr.service.CustomerService;

@Controller
public class CustomerPageController {

	@Autowired
	private CustomerService customerService;

	@RequestMapping(value = "/customers", method = RequestMethod.GET)
	public ModelAndView customerPage() {
		ModelAndView m = new ModelAndView("customerPage");
		ArrayList<Customer> customerList = (ArrayList<Customer>) customerService.getAllCustomer();
		m.addObject("customerList", customerList);
		return m;
	}

	@RequestMapping(value = "/customer/remove", method = RequestMethod.POST)
	public String removeCustomer(List<IdBean> customers) {
		customerService.removeCustomer(customers);
		return "/customer";
	}
	
	@RequestMapping(value = "/customer/add", method = RequestMethod.POST)
	public String addCustomer(Customer customers) {
//		customerService.addOrUpdateCustomer(customers);
		return "/customer";
	}
}
