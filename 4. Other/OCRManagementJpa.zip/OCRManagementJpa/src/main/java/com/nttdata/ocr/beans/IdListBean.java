package com.nttdata.ocr.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class IdListBean implements Serializable {

	private static final long serialVersionUID = 1L;
	List<IdBean> list = new ArrayList<>();

	public List<IdBean> getList() {
		return list;
	}

	public void setList(List<IdBean> list) {
		this.list = list;
	}

}
