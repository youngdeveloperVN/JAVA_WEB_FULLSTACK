package com.nttdata.ocr.service;

import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.nttdata.ocr.beans.IdBean;
import com.nttdata.ocr.beans.LicenseCustomerBean;
import com.nttdata.ocr.beans.StringBean;
import com.nttdata.ocr.beans.StringList;
import com.nttdata.ocr.dao.CustomerDao;
import com.nttdata.ocr.dao.LicenseDao;
import com.nttdata.ocr.dao.RSADao;
import com.nttdata.ocr.entities.Customer;
import com.nttdata.ocr.entities.LicenseKey;
import com.nttdata.ocr.entities.User;
import com.nttdata.ocr.model.InformationMachine;
import com.nttdata.ocr.model.PCCustomer;
import com.nttdata.ocr.model.PCRequestActive;
import com.nttdata.ocr.util.JsonHelper;
import com.nttdata.ocr.util.RSAManager;

@Component(value = "licenseService")
public class LicenseServiceImpl implements LicenseService {

	@Autowired
	private LicenseDao licenseDao;

	@Autowired
	private RSADao rsaDao;
	
	@Autowired
	private CustomerDao customerDao;

	@Override
	public String decPrivateKey(byte[] encrypted) throws Exception {
		try {
			// TODO Auto-generated method stubs
			KeyPair keyPair = buildKeyPair();
			PrivateKey privateKey = keyPair.getPrivate();

			byte[] secret = RSAManager.getInstance().decrypt(privateKey, encrypted);
			return new String(secret);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public static KeyPair buildKeyPair() throws NoSuchAlgorithmException {
		final int keySize = 2048;
		KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
		keyPairGenerator.initialize(keySize);
		return keyPairGenerator.genKeyPair();
	}

	@Override
	public String verifyRequestActive(PCRequestActive requestActive) {
		String sign = "";
		try {
			String rsaID = requestActive.getRsaId();
			String encry = requestActive.getContent();

			String privateKeyString = rsaDao.getPrivateKeyByRSAId(rsaID);
			PrivateKey privateKey = RSAManager.getInstance().getPrivateKeyFromXmlString(privateKeyString);

			if (StringUtils.isEmpty(privateKeyString)) {
				// log.error("Can't not find privateKey with: " + rsaID);
				return null;
			}
			// create privateKey
			String jsonPCCustomer = RSAManager.getInstance().decryptPrivateKey(privateKey, encry,
					StandardCharsets.UTF_16LE);

			PCCustomer pcCustomer = JsonHelper.fromJson(jsonPCCustomer, PCCustomer.class);
			InformationMachine informationPC = pcCustomer.getInformationMachine();

			String licenseKeyCustomer = pcCustomer.getLicenseKey();
			String license = licenseDao.findLicenseKey(rsaID, licenseKeyCustomer);
			if (!license.equals(licenseKeyCustomer)) {
				return null;
			}
			// sign private key
			sign = RSAManager.getInstance().sign(JsonHelper.toJson(informationPC), privateKey);
			//
			licenseDao.updateLicenseString(sign, license);
			// insert information PC
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return sign;
		}
		return sign;
	}

	@Override
	public StringList createOrUpdateLicenseKey(User user, LicenseCustomerBean bean) {
		StringList list = new StringList();
		String customerId = bean.getCustomerId();
		String rsaId = bean.getRsaId();
		int total = bean.getTotalNumber();
		int active = boolToInt(bean.isActive());
		
		Customer customer = customerDao.findCustomerById(customerId);
		if(customer == null ) customerId = null;
		if (StringUtils.isEmpty(rsaId)) {
			//create rsa key and, create license
//			rsaId = rsaDao.createNewKey(user);
		}
		
		List<String> licenses = new ArrayList<>();
		for (int i = 0; i < total; i++) {
			licenses.add(licenseDao.insertLicense(user.getUserName(), customerId, rsaId, active, i));
		}
		list.setList(licenses);
		return list;
	}

//	@Override
//	public List<LicenseKeyVO> getAllLicenseKey() {
//		try {
//			List<LicenseKeyVO> licenseKey = convertListEntitiesToVO(licenseDao.getAllLicenseKey());
//			return licenseKey;
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw e;
//		}
//	}

//	private List<LicenseKeyVO> convertListEntitiesToVO(List<LicenseKey> allLicenseKey) {
//		if(allLicenseKey == null) return null;
//		List<LicenseKeyVO> licenseVOs = new ArrayList<>();
//		for (LicenseKey licenseKey : allLicenseKey) {
//			LicenseKeyVO licenseVO = new LicenseKeyVO();
//			
//			licenseVO.setActivedDate(licenseKey.getActivedDate());
//			licenseVO.setCreateDate(licenseKey.getCreateDate());
//			licenseVO.setCreateUser(licenseKey.getCreateUser());
//			licenseVO.setCustomerId(licenseKey.getCustomerId());
//			
//			licenseVO.setEffectivedDate(licenseKey.getEffectivedDate());
//			licenseVO.setInnitiatedDate(licenseKey.getInnitiatedDate());
//			licenseVO.setIsActived(licenseKey.getIsActived());
//			licenseVO.setLastModifiedDate(licenseKey.getLastModifiedDate());
//			licenseVO.setLastModifiedUser(licenseKey.getLastModifiedUser());
//			licenseVO.setLicenseKey(licenseKey.getLicenseKey());
//			licenseVO.setLicenseString(licenseKey.getLicenseString());
//			licenseVO.setLicenseType(licenseKey.getLicenseType());
//			licenseVO.setRsaID(licenseKey.getRsaID());
//			licenseVO.setStatus(licenseKey.getStatus());
//			
//			Customer customer = customerDao.findCustomerById(licenseKey.getCustomerId());
//			if (customer != null) {
//				licenseVO.setCustomerName(customer.getCustomerName());
//			}
//			licenseVOs.add(licenseVO);
//		}
//		return licenseVOs;
//	}

	@Override
	public StringBean deleteByLicenseKey(List<IdBean> listLicenseKey) {
		StringBean bean = new StringBean();
		String mess= null;
		int countSuccess = 0;
		for (int i = 0; i < listLicenseKey.size(); i++) {
			if (listLicenseKey.get(i) != null && !StringUtils.isEmpty(listLicenseKey.get(i).getId())) {
				String result = licenseDao.deleteByLicenseKey(listLicenseKey.get(i).getId());
				if (StringUtils.isEmpty(result)) {
					String licenseFail = listLicenseKey.get(i).getId();
					mess += "Fail " + licenseFail + " ,";
				} else countSuccess++;
				
			}
		}
		mess += "Success : " + countSuccess;
		bean.setMessage(mess);
		return bean;
	}

	@Override
	public String deleteByCustomerId(String customerId) {
		return licenseDao.deleteByCustomerId(customerId);
	}

	@Override
	public List<LicenseKey> getAllLicenseKey() {
		try {
			List<LicenseKey> licenseKeys = licenseDao.getAllLicenseKey();
			return licenseKeys;
		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;
	}

}
