package com.nttdata.ocr.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.nttdata.ocr.entities.LicenseKey;

@Repository
public interface LicenseKeyRepository extends JpaRepository<LicenseKey, String> {

	final String SELECT_ALL = "SELECT l FROM LicenseKey l ORDER BY l.createDate DESC";

	@Query(SELECT_ALL)
	List<LicenseKey> findAll();
}