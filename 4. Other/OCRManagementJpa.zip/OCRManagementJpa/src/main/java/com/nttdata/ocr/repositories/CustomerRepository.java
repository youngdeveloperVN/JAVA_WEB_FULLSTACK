package com.nttdata.ocr.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.nttdata.ocr.entities.Customer;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, String> {

	final String SELECT_ALL = "SELECT c FROM Customer c ORDER BY c.createDate DESC";

	@Query(SELECT_ALL)
	List<Customer> findAll();
	
}