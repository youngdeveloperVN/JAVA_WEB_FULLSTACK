
package com.nttdata.ocr.model;

import java.io.Serializable;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class InformationMachine implements Serializable {

	@SerializedName("HardDrive")
	@Expose
	public List<HardDrive> hardDrive = null;

	@SerializedName("MacAddress")
	@Expose
	public String macAddress;
	private final static long serialVersionUID = 1L;

	public List<HardDrive> getHardDrive() {
		return hardDrive;
	}

	public void setHardDrive(List<HardDrive> hardDrive) {
		this.hardDrive = hardDrive;
	}

	public String getMacAddress() {
		return macAddress;
	}

	public void setMacAddress(String macAddress) {
		this.macAddress = macAddress;
	}

}