package com.nttdata.ocr.entities;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;


/**
 * The persistent class for the customer database table.
 * 
 */
@Entity
@NamedQuery(name="Customer.findAll", query="SELECT c FROM Customer c")
public class Customer implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="customer_id")
	private String customerId;

	private String address;

	@Column(name="contract_number")
	private String contractNumber;

	@Column(name="create_date")
	private Timestamp createDate;

	@Column(name="create_user")
	private String createUser;

	@Column(name="customer_name")
	private String customerName;

	private String email;

	@Column(name="is_actived")
	private Integer isActived;

	@Column(name="last_modified_date")
	private Timestamp lastModifiedDate;

	@Column(name="last_modified_user")
	private String lastModifiedUser;

	@Column(name="phone_number")
	private String phoneNumber;

	//bi-directional many-to-one association to LicenseKey
	@OneToMany(mappedBy="customer")
	private List<LicenseKey> licenseKeys;

	public Customer() {
	}

	public String getCustomerId() {
		return this.customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getContractNumber() {
		return this.contractNumber;
	}

	public void setContractNumber(String contractNumber) {
		this.contractNumber = contractNumber;
	}

	public Timestamp getCreateDate() {
		return this.createDate;
	}

	public void setCreateDate(Timestamp createDate) {
		this.createDate = createDate;
	}

	public String getCreateUser() {
		return this.createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public String getCustomerName() {
		return this.customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Integer getIsActived() {
		return this.isActived;
	}

	public void setIsActived(Integer isActived) {
		this.isActived = isActived;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getLastModifiedUser() {
		return this.lastModifiedUser;
	}

	public void setLastModifiedUser(String lastModifiedUser) {
		this.lastModifiedUser = lastModifiedUser;
	}

	public String getPhoneNumber() {
		return this.phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public List<LicenseKey> getLicenseKeys() {
		return this.licenseKeys;
	}

	public void setLicenseKeys(List<LicenseKey> licenseKeys) {
		this.licenseKeys = licenseKeys;
	}

	public LicenseKey addLicenseKey(LicenseKey licenseKey) {
		getLicenseKeys().add(licenseKey);
		licenseKey.setCustomer(this);

		return licenseKey;
	}

	public LicenseKey removeLicenseKey(LicenseKey licenseKey) {
		getLicenseKeys().remove(licenseKey);
		licenseKey.setCustomer(null);

		return licenseKey;
	}

}