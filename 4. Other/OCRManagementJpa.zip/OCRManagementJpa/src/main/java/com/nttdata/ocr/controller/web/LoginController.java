package com.nttdata.ocr.controller.web;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.nttdata.ocr.entities.User;
import com.nttdata.ocr.service.UserService;

@Controller
public class LoginController {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private UserService userService;
	/**
	 * Initiation login screen
	 * @return
	 */
//	@RequestMapping(value = "/index", method = RequestMethod.GET)
//	public ModelAndView initLogin(Model model) {
//		ModelAndView mav = new ModelAndView("login/login");
//		mav.addObject("User", new User());
//		return mav;
//	}
//
//	/**
//	 * Check login
//	 * @return
//	 */
//	@PostMapping("/login")
//	public String checkLogin(HttpServletRequest request, HttpServletResponse response, Model model,
//			@Valid @ModelAttribute("User") User userEntity, BindingResult result,RedirectAttributes attributes) {
//		model.addAttribute("userEntity", userEntity);
//		String username = userEntity.getUserName();
//		String password = userEntity.getPassword();
//		
//		//Check empty
//		if (StringUtils.isEmpty(username)||StringUtils.isEmpty(password)) {
//			String errorMsg="Please input both the Username file and Password file.";
//			attributes.addFlashAttribute("errorMsg",errorMsg);
//			return "redirect:index";
//		}
//		//Validate from entity
//		if (result.hasErrors()) {
//			String errorMsg="The Username or Password invalid. Please check again.";
//			attributes.addFlashAttribute("errorMsg",errorMsg);
//			return "redirect:index";
//		}
//
//		//Validate in DB
//		User userLogin = userService.findUserByUserNameAndPass(username, password);
//		
//		if (userLogin == null) {
//			String errorMsg="The Username or Password invalid. Please check again.";
//			attributes.addFlashAttribute("errorMsg",errorMsg);
//			return "redirect:index";
//		}
//		//Create session
//		request.getSession().setAttribute("user", userLogin);
//		
//		return "homePage";
//	}
	
	@RequestMapping(value={"/", "/login"}, method = RequestMethod.GET)
	public ModelAndView login(){
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("login/login");
		return modelAndView;
	}
	
	@RequestMapping(value="/registration", method = RequestMethod.GET)
	public ModelAndView registration(){
		ModelAndView modelAndView = new ModelAndView();
		User user = new User();
		modelAndView.addObject("user", user);
		modelAndView.setViewName("registration");
		return modelAndView;
	}
	
	
	@GetMapping(value = "/logout")
	public String logOut(HttpSession session) {
		//Deactivate session
	    session.invalidate();
		return "redirect:index";
	}

	@GetMapping(value = "/home")
	public String initHome() {
		return "homePage";
	}

	@GetMapping(value = "/contactus")
	public String contactusPage(Model model) {
		model.addAttribute("address", "Vietnam");
		model.addAttribute("phone", "...");
		model.addAttribute("email", "...");
		return "contactusPage";
	}
	
}
