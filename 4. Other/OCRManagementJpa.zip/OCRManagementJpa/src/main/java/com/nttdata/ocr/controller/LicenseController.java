package com.nttdata.ocr.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.nttdata.ocr.beans.IdListBean;
import com.nttdata.ocr.beans.LicenseCustomerBean;
import com.nttdata.ocr.beans.LicenseListBean;
import com.nttdata.ocr.beans.StringBean;
import com.nttdata.ocr.beans.StringList;
import com.nttdata.ocr.common.Constants;
import com.nttdata.ocr.entities.User;
import com.nttdata.ocr.model.PCRequestActive;
import com.nttdata.ocr.service.LicenseService;

@RestController
@RequestMapping("/license")
public class LicenseController {

	@Autowired
	private LicenseService licenseService;

	@RequestMapping(value = "/verifyLicenseKey", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public String verifyLicenseKey(@RequestBody PCRequestActive requestContent) {
		return licenseService.verifyRequestActive(requestContent);
	}

	@RequestMapping(value = "/createLicenseKey", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public StringList createLicenseKey(HttpServletRequest request, HttpServletResponse response,  @RequestBody LicenseCustomerBean licenseCustomer) {
		StringList list = null;
		try {
			User superUser = (User)request.getSession().getAttribute(Constants.KEY_SESSION_USER);
			if (superUser != null ) {
				list = licenseService.createOrUpdateLicenseKey(superUser, licenseCustomer);
				return list;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return list;
	}

	@RequestMapping(value = "/getAllLicenseKey", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public LicenseListBean getAllLicenseKey() {
		LicenseListBean list = new LicenseListBean();
//		list.setList(licenseService.getAllLicenseKey());
		return list;
	}
	
//	@RequestMapping(value = "/deleteLicenseKey", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
//	@ResponseBody
//	public String deleteByLicenseKey(@RequestBody IdBean idBean) {
//		return licenseService.deleteByLicenseKey(idBean.getId());
//	}
//	
	@RequestMapping(value = "/deleteLicenseKey", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public StringBean deleteByLicenseKey(@RequestBody IdListBean listLicense) {
		return licenseService.deleteByLicenseKey(listLicense.getList());
		
	}
	
}