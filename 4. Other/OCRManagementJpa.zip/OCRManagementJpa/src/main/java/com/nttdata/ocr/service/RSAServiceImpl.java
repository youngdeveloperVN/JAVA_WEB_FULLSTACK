package com.nttdata.ocr.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.nttdata.ocr.beans.IdBean;
import com.nttdata.ocr.dao.RSADao;
import com.nttdata.ocr.entities.Rsa;
import com.nttdata.ocr.entities.User;

@Component
public class RSAServiceImpl implements RSAService {

	@Autowired
	private RSADao rsaDao;
	
	@Override
	public boolean addNewKey(User user) {
		// TODO Auto-generated method stub
		return rsaDao.createNewKey(user);
	}

	@Override
	public List<Rsa> getAll() {
		return rsaDao.getAll();
	}

	@Override
	public boolean deleteRSA(List<IdBean> list) {
		for (int i = 0; i < list.size() ; i++) {
			rsaDao.remove(list.get(i).getId());
		}
		return true;
	}

	@Override
	public List<Rsa> getRSANonActive() {
		return rsaDao.selectRSANonActive();
	}
	
}
