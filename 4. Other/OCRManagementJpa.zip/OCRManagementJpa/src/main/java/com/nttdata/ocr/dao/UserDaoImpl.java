package com.nttdata.ocr.dao;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import com.nttdata.ocr.entities.Role;
import com.nttdata.ocr.entities.User;
import com.nttdata.ocr.repositories.RoleRepository;
import com.nttdata.ocr.repositories.UserRepository;

@Component
public class UserDaoImpl implements UserDao {

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;

	@Autowired
    private RoleRepository roleRepository;

	@Override
	public List<User> getAllUsers() {
		try {
			return userRepository.findAll();
		} catch (Exception e) {
			throw e;
		}
	}

	@Override
	public User findUserByUserNameAndPass(String username, String password) {
		return userRepository.findUserByUserNameAndPass(username, password);
	}

	@Override
	public User findByEmail(String email) {
		return userRepository.findByEmail(email);
	}

	@Override
	public void saveUser(User user) {
		user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
        user.setIsActived(1);
        Role userRole = roleRepository.findByRole("ADMIN");
        user.setRole(userRole);
		userRepository.save(user);
	}

}
