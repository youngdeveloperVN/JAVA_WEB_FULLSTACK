package com.nttdata.ocr.beans;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class LicenseCustomerBean implements Serializable {

	private static final long serialVersionUID = -7018138744970682839L;
	
	@JsonProperty("idCustomer")
	private String customerId;
	
	@JsonProperty("totalLicense")
	private int totalNumber;
	
	@JsonProperty("idRsa")
	private String rsaId;
	
	@JsonProperty("isActived")
	private boolean isActive;

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public int getTotalNumber() {
		return totalNumber;
	}

	public void setTotalNumber(int totalNumber) {
		this.totalNumber = totalNumber;
	}

	public String getRsaId() {
		return rsaId;
	}

	public void setRsaId(String rsaId) {
		this.rsaId = rsaId;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

}
