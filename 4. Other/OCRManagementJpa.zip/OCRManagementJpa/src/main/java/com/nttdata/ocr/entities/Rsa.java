package com.nttdata.ocr.entities;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;


/**
 * The persistent class for the rsa database table.
 * 
 */
@Entity
@NamedQuery(name="Rsa.findAll", query="SELECT r FROM Rsa r")
public class Rsa implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="rsa_id")
	private String rsaId;

	@Column(name="create_date")
	private Timestamp createDate;

	@Column(name="create_user")
	private String createUser;

	@Column(name="is_actived")
	private Integer isActived;

	@Column(name="last_modified_date")
	private Timestamp lastModifiedDate;

	@Column(name="last_modified_user")
	private String lastModifiedUser;

	@Column(name="private_key")
	private String privateKey;

	@Column(name="public_key")
	private String publicKey;

	//bi-directional many-to-one association to LicenseKey
	@OneToMany(mappedBy="rsa")
	private List<LicenseKey> licenseKeys;

	public Rsa() {
	}

	public String getRsaId() {
		return this.rsaId;
	}

	public void setRsaId(String rsaId) {
		this.rsaId = rsaId;
	}

	public Timestamp getCreateDate() {
		return this.createDate;
	}

	public void setCreateDate(Timestamp createDate) {
		this.createDate = createDate;
	}

	public String getCreateUser() {
		return this.createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public Integer getIsActived() {
		return this.isActived;
	}

	public void setIsActived(Integer isActived) {
		this.isActived = isActived;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getLastModifiedUser() {
		return this.lastModifiedUser;
	}

	public void setLastModifiedUser(String lastModifiedUser) {
		this.lastModifiedUser = lastModifiedUser;
	}

	public String getPrivateKey() {
		return this.privateKey;
	}

	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}

	public String getPublicKey() {
		return this.publicKey;
	}

	public void setPublicKey(String publicKey) {
		this.publicKey = publicKey;
	}

	public List<LicenseKey> getLicenseKeys() {
		return this.licenseKeys;
	}

	public void setLicenseKeys(List<LicenseKey> licenseKeys) {
		this.licenseKeys = licenseKeys;
	}

	public LicenseKey addLicenseKey(LicenseKey licenseKey) {
		getLicenseKeys().add(licenseKey);
		licenseKey.setRsa(this);

		return licenseKey;
	}

	public LicenseKey removeLicenseKey(LicenseKey licenseKey) {
		getLicenseKeys().remove(licenseKey);
		licenseKey.setRsa(null);

		return licenseKey;
	}

}