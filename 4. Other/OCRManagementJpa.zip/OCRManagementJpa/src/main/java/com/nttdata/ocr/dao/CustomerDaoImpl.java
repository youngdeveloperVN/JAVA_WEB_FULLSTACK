package com.nttdata.ocr.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.nttdata.ocr.entities.Customer;
import com.nttdata.ocr.repositories.CustomerRepository;

@Component
public class CustomerDaoImpl implements CustomerDao {

	@Autowired
	private CustomerRepository customerRepository;

	@Override
	public boolean insertCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public Customer findCustomerById(String customerId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean deleteCustomerById(String customerId) {
		// TODO Auto-generated method stub
		return false;
	}

//	@Override
//	public boolean insertCustomer(Customer customer) {
//		boolean isSuccess = false;
//		try {
//			customerMapper.insertCustomer(customer);
//			isSuccess = true;
//		} catch (PersistenceException e) {
//			// TODO: handle exception
//			throw e;
//		}
//		return isSuccess;
//	}
//
//	@Override
//	public boolean updateCustomer(Customer customer) {
//		boolean isSuccess = false;
//		try {
//			customerMapper.updateCustomer(customer);
//			isSuccess = true;
//		} catch (PersistenceException e) {
//			// TODO: handle exception
//			throw e;
//		}
//		return isSuccess;
//	}
//	
	@Override
	public List<Customer> findAllCustomer() {
		try {
			return customerRepository.findAll();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			throw e;
		}
	}
//
//	@Override
//	public boolean deleteCustomerById(String customerId) {
//		try {
//			customerMapper.deleteCustomerById(customerId);
//			return true;
//		} catch (Exception e) {
//			// TODO: handle exception
//		}
//		return true;
//	}
//
//	@Override
//	public Customer findCustomerById(String customerId) {
//		try {
//			List<Customer> customerList = customerMapper.findCustomerById(customerId);
//			if (customerList.isEmpty()) return null;
//			return customerList.get(0);
//		} catch (Exception e) {
//			throw e;
//		}
//	}
}
