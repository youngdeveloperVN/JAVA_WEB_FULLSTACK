package com.nttdata.ocr.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.nttdata.ocr.beans.IdBean;
import com.nttdata.ocr.beans.UserBean;
import com.nttdata.ocr.dao.UserDao;
import com.nttdata.ocr.entities.User;

@Component
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao userDao;

	@Override
	public ArrayList<User> getAll() {
		ArrayList<User> listUsers = (ArrayList<User>) userDao.getAllUsers();
		return listUsers;
	}

	@Override
	public User getUserByUserName(String username) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean addOrUpdateUser(User superUser, UserBean userBean) {
		return false;
	}

	@Override
	public boolean deleteUserName(List<IdBean> list) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public User findUserByUserNameAndPass(String username, String password) {
		User user = userDao.findUserByUserNameAndPass(username, password);
		return user;
	}

	@Override
	public User findUserByEmail(String email) {
		return userDao.findByEmail(email);
	}

	@Override
	public void saveUser(User user) {
		userDao.saveUser(user);
	}

}
