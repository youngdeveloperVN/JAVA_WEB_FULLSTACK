package com.nttdata.ocr.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class StringList implements Serializable {

	private static final long serialVersionUID = -2870725767681128207L;
	List<String> list = new ArrayList<>();

	public List<String> getList() {
		return list;
	}

	public void setList(List<String> list) {
		this.list = list;
	}

}
