package com.nttdata.ocr.service;

import java.util.List;

import com.nttdata.ocr.beans.CustomerBean;
import com.nttdata.ocr.beans.IdBean;
import com.nttdata.ocr.common.GenericService;
import com.nttdata.ocr.entities.Customer;
import com.nttdata.ocr.entities.User;

public interface CustomerService extends GenericService {
	
	boolean addOrUpdateCustomer(CustomerBean customerBean, User user);
	boolean removeCustomer(List<IdBean> list);
	CustomerBean getCustomerById(String customerId);
	List<Customer> getAllCustomer();
	
}
