
package com.nttdata.ocr.model;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class HardDrive implements Serializable {

	@SerializedName("Model")
	@Expose
	public String model;
	@SerializedName("Type")
	@Expose
	public String type;
	@SerializedName("SerialNo")
	@Expose
	public String serialNo;
	private final static long serialVersionUID = 1L;

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getSerialNo() {
		return serialNo;
	}

	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}

}