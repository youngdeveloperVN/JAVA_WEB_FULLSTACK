package com.nttdata.ocr.util;

public class GeneratorID {
	
	//create by date + string cointain
	// Tinh Van Outsourcing => TVO + 2018-12-15 08:00:00 => TVO20181215080000
	public static String  createId(String text) {
	    String result = text.replaceAll("\\B.|\\P{L}", "").toUpperCase();
		return result + DateHelper.nowToString();
	}
	
}
