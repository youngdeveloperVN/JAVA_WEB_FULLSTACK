package com.nttdata.ocr.service;

import java.util.List;

import com.nttdata.ocr.beans.IdBean;
import com.nttdata.ocr.entities.Rsa;
import com.nttdata.ocr.entities.User;

public interface RSAService {
	public boolean addNewKey(User user);
	
	List<Rsa> getAll();

	public boolean deleteRSA(List<IdBean> bean);	
	
	List<Rsa> getRSANonActive();
}
