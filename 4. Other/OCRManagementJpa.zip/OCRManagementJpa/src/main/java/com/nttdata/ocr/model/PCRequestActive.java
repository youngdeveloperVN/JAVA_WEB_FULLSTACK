package com.nttdata.ocr.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PCRequestActive {

	@JsonProperty("RequestContent")
	private String content;

	@JsonProperty("RSAID")
	private String rsaId;

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getRsaId() {
		return rsaId;
	}

	public void setRsaId(String rsaId) {
		this.rsaId = rsaId;
	}
}
