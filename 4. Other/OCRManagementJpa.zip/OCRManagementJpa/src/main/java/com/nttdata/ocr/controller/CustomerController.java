package com.nttdata.ocr.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.nttdata.ocr.beans.CustomerBean;
import com.nttdata.ocr.beans.CustomerListBean;
import com.nttdata.ocr.beans.IdListBean;
import com.nttdata.ocr.common.Constants;
import com.nttdata.ocr.entities.Customer;
import com.nttdata.ocr.entities.User;
import com.nttdata.ocr.service.CustomerService;

@RestController
@RequestMapping("/customers")
public class CustomerController {

	@Autowired
	private CustomerService customerService;

	@RequestMapping(value = "/", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public CustomerListBean getAll() {
		CustomerListBean customerListBean = new CustomerListBean();
		ArrayList<Customer> customerList = (ArrayList<Customer>) customerService.getAllCustomer();
		customerListBean.setList(customerList);
		return customerListBean;
	}

	@RequestMapping(value = "/create", consumes = MediaType.APPLICATION_JSON_VALUE ,produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	@ResponseBody
	public boolean createCustomer(@RequestBody CustomerBean customerBean, HttpServletRequest request, HttpServletResponse response) {
		User superUser = (User)request.getSession().getAttribute(Constants.KEY_SESSION_USER);
		if (superUser != null ) {
			return customerService.addOrUpdateCustomer(customerBean, superUser);
		}
		return false;
	}
	
	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public CustomerBean findCustomerById(@PathVariable("id") String id) {
		return customerService.getCustomerById(id);
	}
	
	@RequestMapping(value = "/delete", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public boolean deleteCustomerById(@RequestBody IdListBean idListBean) {
		return customerService.removeCustomer(idListBean.getList());
	}

}