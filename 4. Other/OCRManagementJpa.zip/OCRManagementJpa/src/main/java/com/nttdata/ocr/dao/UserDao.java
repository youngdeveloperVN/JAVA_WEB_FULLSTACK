package com.nttdata.ocr.dao;

import java.util.List;

import com.nttdata.ocr.entities.User;

public interface UserDao {

	public List<User> getAllUsers();
	public User findUserByUserNameAndPass(String username, String password);
	public User findByEmail(String email);
	public void saveUser(User user);
}
