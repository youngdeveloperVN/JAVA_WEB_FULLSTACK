package com.nttdata.ocr.dao;

import java.util.List;

import com.nttdata.ocr.common.GenericDao;
import com.nttdata.ocr.entities.Customer;

public interface CustomerDao extends GenericDao {

	public boolean insertCustomer(Customer customer);
	public boolean updateCustomer(Customer customer);
	List<Customer> findAllCustomer();
	Customer findCustomerById(String customerId);
	public boolean deleteCustomerById(String customerId);

}