/*INSTANTCE VARIABLE*/
var navbar;
var sticky;
var navigatorOCR;
var activeClass = "fa fa-angle-down";

var CUSTOMER_GET_ALL_URL = "customers/";
var CUSTOMER_DELETE_URL = "customers/delete";
var CUSTOMER_CREARE_URL = "customers/create";

var LICENSE_GET_ALL_URL = "license/getAllLicenseKey";
var LICENSE_DELETE_URL = "license/deleteLicenseKey";
var LICENSE_CREARE_URL = "license/createLicenseKey";
var LICENSE_VERIFY_URL = "license/verifyLicenseKey";

var USER_GET_ALL_URL = "users/";
var USER_DELETE_URL = "users/delete";
var USER_CREARE_URL = "users/add";

var RSA_GET_ALL_URL = "/rsakey";
var RSA_DELETE_URL = "rsakey/delete";
var RSA_CREARE_URL = "rsakey/create";

var btnBackToTop = 'return-to-top';


// *active menu*/
/* For active click menu* */
function setMenuActiveEvent() {
	// listen click <a> in navigator
	var listA = navigatorOCR.getElementsByTagName("a");
	for (var i = 0; i < listA.length; i++) {
		listA[i].onclick = function() {
			// find and clear all active class
			var activeList = navigatorOCR.getElementsByClassName("active");
			for (var j = 0; j < activeList.length; j++) {
				activeList[j].classList.remove("active");
			}
		}
	}
}

function loadMenuActive() {
	//get active menu
	var url = window.location.href;
	var listA = navigatorOCR.getElementsByTagName("a");
	
	for (var i = 0; i < listA.length; i++) {
		if (url.indexOf(listA[i].href) !== -1) {
			listA[i].classList.add("active");
			var elementI = listA[i].getElementsByTagName("i")[0];
			elementI.className = activeClass;
		}
	}
}

//effect to button "back to top"
function backToTopButton() {
	if ($(this).scrollTop() >= 50) { // If page is scrolled more than
		// 50px
		$('#return-to-top').fadeIn(200); // Fade in the arrow
	} else {
		$('#return-to-top').fadeOut(200); // Else fade out the arrow
	}
}

//click back to top
function setUpBackToTopAction() {
	$('#' + btnBackToTop).click(function() { // When arrow is clicked
		$('body,html').animate({
			scrollTop : 0
		// Scroll to top of body
		}, 500);
	});
}

function getStorage() {
	if (typeof (Storage) !== "undefined") {
		return sessionStorage;
	} else {
		alert("Website can't support to your brower");
		return null;
	}
}

window.onscroll = function() {
	//myFunction();
	backToTopButton();
}

window.onload = function() {
	navbar = document.getElementById("navbar");
	sticky = navbar.offsetTop + 200;
	navigatorOCR = document.getElementsByClassName("sidebar")[0];
	setMenuActiveEvent();
	loadMenuActive();
	setUpBackToTopAction();
}

//convert form to object
$.fn.serializeObject = function() {
	var o = {};
	var a = this.serializeArray();
	$.each(a, function() {
		if (o[this.name] !== undefined) {
			if (!o[this.name].push) {
				o[this.name] = [ o[this.name] ];
			}
			o[this.name].push(this.value || '');
		} else {
			o[this.name] = this.value || '';
		}
	});
	return o;
}

//selected only row
function setUpSelectedTrTable(tableId){
	var table = $('#'+tableId).DataTable();
    $('#'+tableId+ ' tbody').on( 'click', 'tr', function () {
        if ( $(this).hasClass('selected') ) {
            $(this).removeClass('selected');
        }
        else {
            table.$('tr.selected').removeClass('selected');
            $(this).addClass('selected');
        }
    } );
}

function setUpCloseModel() {
	$("span.close").click(function() {
		$(this).parents('.modal').hide();
	});
}

//reset form
function resetForm(idForm){
	$('#'+idForm).find('input[type=email]').val('');
	$('#'+idForm).find('input[type=password]').val('');
	$('#'+idForm).find('input[type=checkbox]').prop('checked', false);
	$('#'+idForm).find('textarea').val('');
	$('#'+idForm).find('input[type=text]').val('');
	$('#'+idForm).find('input[type=number]').val(0);
	$('#'+idForm).find('input[type=hidden]').val(0);
	
	var selectList = $('#'+idForm).find('select');
	for ( var selectItem in selectList) {
		$(selectItem).prop('selectedIndex', 0);
	}
	
	//find class error to hide
	$('#'+idForm).find('p[class*=error]').addClass('hide');
}

function showLoading(){
	$('.loading').show();
}

function hideLoading(){
	$('.loading').hide();
}

function createNewRSAKey(){
	showLoading();
	$.ajax({
		url : RSA_CREARE_URL,
		type : "POST",
		data : null,
		contentType : 'application/json',
		success : function(data) {
			if (data && data.message ) {
				alert("New key: " + data.message);
				//tbl.ajax.reload(); //location.reload();
			} else {
				alert("Failed");
			}
		},
		error : function(jqXHR, textStatus,
				errorThrown) {
		},
		complete : function(data) {
			hideLoading();
		},
		timeout : 120000,
	});
}
