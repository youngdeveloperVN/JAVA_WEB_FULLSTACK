var tbl;
var modeNew = 'new';
var modeEdit = 'edit';
var tableId = 'usersTable';
var modalUserEdit = 'modalUserEdit';
var formAddEditUser = 'editUser';
var btnDeleteUser = 'deleteUser';
var btnAddUser = 'addUser';

$(document).ready(function() {
	showDataUser();
	//setUpOnSubmitAddUser();
	setUpOnClickDeleteUser();
	setUpCloseModel();
	setUpOnSubmitEditCusomer();
	setUpAddUserModal();
	setUpSelectedTrTable(tableId);
});

function showDataUser() {
	tbl = $('#'+tableId).DataTable({
		columnDefs : [ {
			'targets' : 0,
			'checkboxes' : {}
		} ],
		select : {
			style : 'multi'
		},
		order : [ [ 1, 'desc' ] ],
	});
}

function setUpOnClickDeleteUser() {
	$('#' + btnDeleteUser).click(function(event) {
		var rows_selected = tbl.column(0).checkboxes.selected();
		var total = rows_selected.length;

		if (rows_selected.length <= 0)
			alert("You must be choose a user");
		else
			alert("Do you want delete " + total + " users?");
		var listId = {
				list: new Array()
		}
		$.each(rows_selected, function(index, rowId) {
			var idBean = {
				id : rowId
			}
			listId.list.push(idBean);
		});
		var json = JSON.stringify(listId);
		showLoading();
		$.ajax({
			url : USER_DELETE_URL,
			type : "POST",
			data : json,
			contentType : 'application/json',
			success : function(data) {
//				if (data == true) {
//					//alert("Delete user is successful");
//				} else
//					alert("Can't delete user");
			},
			error : function(jqXHR, textStatus, errorThrown) {
				alert("Can't delete user");
			},
			complete : function(data) {
				tbl.ajax.reload(); //location.reload();
				hideLoading();
			},
			timeout : 120000,
		});
	});
}

function setUpOnSubmitEditCusomer(){
	
	$('#' +formAddEditUser).submit(function(event) {
		
		var dataForm = $(this).serializeObject();
		dataForm.isActived = $(
				"input[type='checkbox'][name = 'isActived']")
				.prop("checked");
		var json = JSON.stringify(dataForm);
		$.ajax({
			url : USER_CREARE_URL,
			type : "POST",
			data : json,
			contentType : 'text/json',
			success : function(data) {
				if (data == true) {
					alert("Successful");
					tbl.ajax.reload(); //location.reload();
				} else alert("Failed");
			},
			error : function(jqXHR, textStatus,
					errorThrown) {
			},
			complete : function(data) {
				tbl.ajax.reload(); //location.reload();
			},
			timeout : 120000,
		});
		event.preventDefault();
		$(this).parents('.modal').hide();
	});
}

//show modal table
function showEditUserModal(btnEdit) {
	var trSelected = $(btnEdit).parent().parent();
	 var user = tbl.rows(trSelected).data()[0];
	 showModalUser(user);
}

function setUpAddUserModal() {
	$('#'+btnAddUser).on('click', function(){
		//reset value before show
//		$('#modalUserEdit input[type=email], #modalUserEdit input[type=password], #modalUserEdit input[type=text], textarea').val("");
//		$('#modalUserEdit input[type=checkbox]').prop('checked', false);
		resetForm(formAddEditUser);
		
		$('#'+modalUserEdit).show();
	});
}

function showModalUser(user){
	var result = Object.keys(user).map(function(key) {
		  return [key, user[key]];
	});
	for (var i = 0; i < result.length; i++) {
		var name = result[i][0];
		var valueitem = result[i][1];
		var attr = $('#' +formAddEditUser).find("[name="+name+"]");
		if(attr.length) {
			if(attr.attr('type') == "checkbox"){
				var active = valueitem == 1 ? true : false;
				attr.prop("checked", active);
			}
			attr.val(valueitem);
		}
		else {
			$('#' +formAddEditUser).append('<input type="hidden" name='+ name +' value='+ valueitem +'>');
		}
	}
	
	$('#'+modalUserEdit).show();
}