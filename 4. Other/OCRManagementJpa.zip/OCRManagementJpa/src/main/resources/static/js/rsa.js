var tbl;
var tableId = 'rsaTable';

var rsaForm = "rsaForm";
var formDetailRSA = 'editRsa';
var modalRsa = 'modalRsaEdit';
var btnAddRSAKey = 'addRSAKey';
var btnDeleteRsa = 'deleteRsa';

var COLUMN_RSA_ID = "1";
var COLUMN_PRIVATE_KEY = "4";
var COLUMN_PUBLIC_KEY = "5";

$(document).ready(function() {
	showDataRsa();
	setSelectedSingleRow();
	// setUpOnSubmitAddRsa();
	setUpOnClickDeleteRsa();
	setUpCloseModel();
	setUpAddRsaModal();
	setUpSelectedTrTable(tableId);
	hideLoading();

});

function showDataRsa() {
	tbl = $('#' + tableId).DataTable({
		columnDefs : [ {
			'targets' : 0,
			'checkboxes' : {}
		} ],
		select : {
			style : 'multi'
		},
		order : [ [ 1, 'desc' ] ],
	});
}

function setUpOnClickDeleteRsa() {
	$('#' + btnDeleteRsa).click(function(event) {
		var rows_selected = tbl.column(0).checkboxes.selected();
		var total = rows_selected.length;

		if (rows_selected.length <= 0)
			alert("You must be choose a rsa");
		else
			alert("Do you want delete " + total + " rsas?");
		var listId = {
			list : new Array()
		}
		$.each(rows_selected, function(index, rowId) {
			var idBean = {
				id : rowId
			}
			listId.list.push(idBean);
		});
		var json = JSON.stringify(listId);
		alert(json);
		
		showLoading();
		$.ajax({
			url : RSA_DELETE_URL,
			type : "POST",
			data : json,
			contentType : 'application/json',
			success : function(data) {
				// if (data == true) {
//				 alert("Successful");
				// } else
				// alert("Failed");
			},
			error : function(jqXHR, textStatus, errorThrown) {
				alert("Can't delete user");
			},
			complete : function(data) {
//				tbl.ajax.reload(); // location.reload();
				tbl.destroy();
				showDataRsa();
				hideLoading();
			},
			timeout : 120000,
		});
	});
}

// show modal table
function showEditRsaModal(btnEdit) {
	var trSelected = $(btnEdit).parent().parent();
	var rsa = tbl.rows(trSelected).data()[0];
	showModalRsa(rsa);
}

function setUpAddRsaModal() {
	$('#' + btnAddRSAKey).on('click', function(event) {
		// create new rsa key
		showLoading();
		$.ajax({
			url : RSA_CREARE_URL,
			type : "POST",
			data : null,
			contentType : 'text/html',
			success : function(response) {
				var replaceValue = $(response).find('#'+ tableId).html();
				$('#'+ tableId).html(replaceValue);
			},
			error : function(jqXHR, textStatus, errorThrown) {
			},
			complete : function(data) {
				tbl.destroy();
				showDataRsa();
				hideLoading();
			},
			timeout : 120000,
		});
		event.preventDefault();
	});
}

function showModalRsa(rsa) {
	var result = Object.keys(rsa).map(function(key) {
		return [ key, rsa[key] ];
	});
	for (var i = 0; i < result.length; i++) {
		var name = result[i][0];
		var valueitem = result[i][1];
		var attr = $('#' + formDetailRSA).find("[name=" + name + "]");
		if (attr.length) {
			if (attr.attr('type') == "checkbox") {
				var active = valueitem == 1 ? true : false;
				attr.prop("checked", active);
			}
			attr.val(valueitem);
		}
//		else {
//			$('#' + formDetailRSA).append(
//					'<input type="hidden" name=' + name + ' value=' + valueitem
//							+ '>');
//		}
	}

	$('#' + modalRsa).show();
}

function setSelectedSingleRow(){
	$('#'+ tableId +' tbody').on( 'click', 'tr', function () {
	    if ( $(this).hasClass('selected') ) {
	        $(this).removeClass('selected');
	    }
	    else {
	        tbl.$('tr.selected').removeClass('selected');
	        $(this).addClass('selected');
	    }
	} );
}

