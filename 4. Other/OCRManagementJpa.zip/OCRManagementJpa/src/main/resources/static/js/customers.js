var tbl;
var modalEditAddCustomer = 'modalCustomerEdit';
var editCustomer = 'editCustomer';
var tableId = 'customersTable';
var btnDelete = 'deleteCustomer';
var btnAddCustomer = 'addCustomer';

$(document).ready(function() {
	showDataCustomer();
	
	//setUpOnSubmitAddCustomer();
	setUpOnClickDeleteCustomer();
	setUpOnSubmitEditCusomer();
	setUpAddCustomerModal();
	setUpSelectedTrTable(tableId);
//	setUpNewRSA();
	setUpCloseModel();
});

function showDataCustomer() {
	
	tbl = $('#' + tableId).DataTable({
		columnDefs : [ {
			'targets' : 0,
			'checkboxes' : {}
		} ],
		select : {
			style : 'multi'
		},
		order : [ [ 1, 'desc' ] ],
	});
//	
//	tbl = $('#' + tableId)
//			.DataTable(
//					{
//						ajax : {
//							url : CUSTOMER_GET_ALL_URL,
//							type : 'GET',
//							contentType : 'application/json; charset=utf-8',
//							dataSrc : 'list'
//						},
//						columnDefs : [ {
//							'targets' : 0,
//							'checkboxes' : {
//							}
//						} ],
//						select : {
//							style : 'multi'
//						},
//						order : [ [ 1, 'desc' ] ],
//						columns : [
//								{
//									title : "Item",
//									data : "customerID",
//									type : "checkbox",
//								},
//								{
//									title : "Create Date",
//									data : "createDate",
//									className: "hide"
//								},
//								{
//									title : "Customer Name",
//									data : "customerName"
//								},
//								{
//									title : "Phone Number",
//									data : "phoneNumber"
//								},
//								{
//									title : "Contract Number",
//									data : "contractNumber"
//								},
//								{
//									title : "Email",
//									data : "email"
//								},
//								{
//									title : "Address",
//									data : "address"
//								},
//								{
//									title : "Active",
//									data : "isActived",
//									render : function(data, type, row) {
//										if (data != 0) return '<input type="checkbox" class="editor-active" disabled checked>';
//										else return '<input type="checkbox" class="editor-active" disabled>';
//									},
//									className : "dt-body-center"
//								},
//								{
//									title : "Action",
//									data : "customerID",
//									render : function(data, type, row) {
//										return "<a id='edit_"
//												+ data
//												+ "' onclick='return showEditCustomerModal(this);' href='#' class='btn btn-edit btn-info'><i class='fa fa-pencil-square-o' aria-hidden='true'></i>Edit</a>";
//									}	
//								} ],
//						rowCallback : function(row, data, index) {
//							$('td:eq(0)', row).addClass('checkbox-item ' + data.customerID);
//						},
//					});
}

function setUpOnClickDeleteCustomer() {
	$('#'+ btnDelete).click(function(event) {
		tbl = $('#' + tableId).DataTable();
		var rows_selected = tbl.column(0).checkboxes.selected();
		var total = rows_selected.length;

		if (rows_selected.length <= 0)
			alert("You must be choose a customer");
		else
			alert("Do you want delete " + total + " customers?");

		var listId = {
				list: new Array()
		}
		$.each(rows_selected, function(index, rowId) {
			var idBean = {
				id : rowId
			}
			listId.list.push(idBean);
		});
		var json = JSON.stringify(listId);
		showLoading();
		$.ajax({
			url : CUSTOMER_DELETE_URL,
			type : "POST",
			data : json,
			contentType : 'application/json',
			success : function(data) {
				tbl.ajax.reload();
//				if (data == true) {
//					//alert("Delete user is successful");
//				} else
//					alert("Can't delete user");
			},
			error : function(jqXHR, textStatus, errorThrown) {
				alert("Can't delete user");
			},
			complete : function(data) {
				tbl.ajax.reload(); //location.reload();
				hideLoading();
			},
			timeout : 120000,
		});
	});
}

//save or new customer
function setUpOnSubmitEditCusomer(){
	
	$('#' + editCustomer).submit(function(event) {
		var dataForm = $(this).serializeObject();
		dataForm.isActived = $(
				"input[type='checkbox'][name = 'isActived']")
				.prop("checked");
		var json = JSON.stringify(dataForm);
		showLoading();
		$.ajax({
			url : CUSTOMER_CREARE_URL,
			type : "POST",
			data : json,
			contentType : 'application/json',
			success : function(data) {
				if (data == true) {
					tbl.ajax.reload(); //location.reload();
					alert("Successful");
				} else alert("Failed");
			},
			error : function(jqXHR, textStatus,
					errorThrown) {
			},
			complete : function(data) {
				tbl.ajax.reload(); //location.reload();
				hideLoading();
			},
			timeout : 120000,
		});
		event.preventDefault();
		$(this).parents('.modal').hide();
	});
}

//show modal table
function showEditCustomerModal(btnEdit) {
	var trSelected = $(btnEdit).parent().parent();
	 var customer = tbl.rows(trSelected).data()[0];
	 showModalCustomer(customer);
}

function setUpAddCustomerModal() {
	$('#' + btnAddCustomer).on('click', function(){
		//reset value before show
//		$('#modalCustomerEdit input[type=email], #modalCustomerEdit input[type=text], textarea').val("");
//		$('#modalCustomerEdit input[type=checkbox]').prop('checked', false);
		resetForm(modalEditAddCustomer);
		$('#' + modalEditAddCustomer).show();
	});
}

function showModalCustomer(customer){
	var result = Object.keys(customer).map(function(key) {
		  return [key, customer[key]];
	});
	for (var i = 0; i < result.length; i++) {
		var name = result[i][0];
		var valueitem = result[i][1];
		var attr = $('#' + editCustomer).find("[name="+name+"]");
		if(attr.length) {
			if(attr.attr('type') == "checkbox"){
				var active = valueitem == 1 ? true : false;
				attr.prop("checked", active);
			}
			attr.val(valueitem);
		}
		else {
			$('#' + editCustomer).append('<input type="hidden" name='+ name +' value='+ valueitem +'>');
		}
	}
	
	$('#' + modalEditAddCustomer).show();
}