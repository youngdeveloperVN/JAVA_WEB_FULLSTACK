var tbl;
var formAddLicense = 'formAddLicense';
var modalLicense = 'modalLicenseAdd';
var tableId = 'licensesTable';
var btnDelete = 'deleteLicense';
var btnAdd = 'addLicense';
var selectCustomerClass = 'selectChooseCustomer';
var selectRSA = 'selectChooseRSA';
var newRSAForCustomer = 'newRSAForCustomer';
var idCustomerInput = 'idCustomer';
var idRSAInput = 'idRsa';

//var btnAddCustomer = 'addCustomer';
//var modalEditAddCustomer = 'modalCustomerEdit';
//var editCustomer = 'editCustomer';

$(document).ready(function() {
	showDataLicense();
	
	// setUpOnSubmitAddLicense();
	setUpOnClickDeleteLicense();
	setUpOnSubmitAddLicense();
	setUpAddLicenseModal();
	setUpSelectedTrTable(tableId);
	setUpSelectCreateLicense();
	setUpNewRSA();
	setUpCloseModel();
	
});

function showDataLicense() {
	tbl = $('#' + tableId).DataTable({
		columnDefs : [ {
			'targets' : 0,
			'checkboxes' : {}
		} ],
		select : {
			style : 'multi'
		},
		order : [ [ 1, 'desc' ] ],
	});
//	
//	tbl = $('#' + tableId)
//			.DataTable(
//					{
//						ajax : {
//							url : LICENSE_GET_ALL_URL,
//							type : 'GET',
//							contentType : 'application/json; charset=utf-8',
//							dataSrc : 'list'
//						},
//						columnDefs : [ {
//							'targets' : 0,
//							'checkboxes' : {}
//						} ],
//						select : {
//							style : 'multi'
//						},
//						order : [ [ 1, 'desc' ] ],
//						columns : [
//								{
//									title : "Item",
//									data : "licenseKey",
//									type : "checkbox",
//								},
//								{
//									title : "Create Date",
//									data : "createDate",
//									className : "hide"
//								},
//								{
//									title : "Customer",
//									data : "customerName"
//								},
//								{
//									title : "License Key",
//									data : "licenseKey"
//								},
//								{
//									title : "RSA Id",
//									data : "rsaID"
//								},
//								{
//									title : "Create User",
//									data : "createUser"
//								},
//								{
//									title : "Active",
//									data : "isActived",
//									render : function(data, type, row) {
//										if (data == 1)
//											return '<input type="checkbox" class="editor-active" disabled checked>';
//										else
//											return '<input type="checkbox" class="editor-active" disabled>';
//									},
//									className : "dt-body-center"
//								},
//								{
//									title : "Action",
//									data : "customerID",
//									render : function(data, type, row) {
//										return "<a id='edit_"
//												+ data
//												+ "' onclick='return showAddLicenseModal(this);' href='#' class='btn btn-edit btn-info'><i class='fa fa-pencil-square-o' aria-hidden='true'></i>Edit</a>";
//									}
//								} ],
//						rowCallback : function(row, data, index) {
//							$('td:eq(0)', row).addClass(
//									'checkbox-item ' + data.licenseID);
//						},
//					});
}

function setUpOnClickDeleteLicense() {
	$('#' + btnDelete).click(function(event) {
		var rows_selected = tbl.column(0).checkboxes.selected();
		var total = rows_selected.length;

		if (rows_selected.length <= 0)
			alert("You must be choose a license");
		else
			alert("Do you want delete " + total + " licenses?");

		var listId = {
				list: new Array()
		}
		$.each(rows_selected, function(index, rowId) {
			var idBean = {
				id : rowId
			}
			listId.list.push(idBean);
		});
		var json = JSON.stringify(listId);
		showLoading();
		$.ajax({
			url : LICENSE_DELETE_URL,
			type : "POST",
			data : json,
			contentType : 'application/json',
			success : function(data) {
				// if (data == true) {
				// //alert("Delete user is successful");
				// } else
				// alert("Can't delete user");
			},
			error : function(jqXHR, textStatus, errorThrown) {
				alert("Can't delete user");
			},
			complete : function(data) {
				tbl.ajax.reload(); // location.reload();
				hideLoading();
			},
			timeout : 120000,
		});
		
	});
}

function setUpOnSubmitAddLicense() {

	$('#' + formAddLicense).submit(function(event) {
		
			// validate form
			var idCustomer = $('input[name = '+idCustomerInput+']').val().trim();
			var idRSA = $('input[name = '+idRSAInput+']').val().trim();
			if(idCustomer.length <= 0 || idCustomer == 0 || idRSA.length <= 0 || idRSA == 0) {
				if(idRSA.length <= 0 || idRSA == 0){
					$('.error_rsa').removeClass('hide'); 
				} 
				if(idCustomer.length <= 0 || idCustomer == 0){
					$('.error_customer').removeClass('hide'); 
				} 
				return false;
			} 
			
			showLoading();
			var dataForm = $(this).serializeObject();
			dataForm.isActived = $(
					"input[type='checkbox'][name = 'isActived']").prop(
					"checked");
			var json = JSON.stringify(dataForm);
			$.ajax({
				url : LICENSE_CREARE_URL,
				type : "POST",
				data : json,
				contentType : 'application/json',
				success : function(data) {
					if(data) alert("Successful");
				},
				error : function(jqXHR, textStatus, errorThrown) {
				},
				complete : function(data) {
					tbl.ajax.reload(); // location.reload();
					hideLoading();
				},
				timeout : 120000,
			});
			event.preventDefault();
			$(this).parents('.modal').hide();
		});
}

// show modal table
function showAddLicenseModal(btnEdit) {
	var trSelected = $(btnEdit).parent().parent();
	var license = tbl.rows(trSelected).data()[0];
	showModalLicense(license);
}

function setUpAddLicenseModal() {
	$('#' + btnAdd).on('click', function() {
		var hasCustomer = $('select.'+ selectCustomerClass).children().length > 1 ? true : false;
		if(!hasCustomer) {
			alert("Must be create customer before create license"); return;
		}
		// reset value before show
		resetForm(formAddLicense);
		$('#' + modalLicense).show();
	});
}

function showModalLicense(license) {
	var result = Object.keys(license).map(function(key) {
		return [ key, license[key] ];
	});
	for (var i = 0; i < result.length; i++) {
		var name = result[i][0];
		var valueitem = result[i][1];
		var attr = $('#' + formAddLicense).find("[name=" + name + "]");
		if (attr.length) {
			if (attr.attr('type') == "checkbox") {
				var active = valueitem == 1 ? true : false;
				attr.prop("checked", active);
			}
			attr.val(valueitem);
		} else {
			$('#' + formAddLicense).append(
					'<input type="hidden" name=' + name + ' value=' + valueitem
							+ '>');
		}
	}

	$('#' + modalLicense).show();
}

function setUpSelectCreateLicense(){
	$("select." + selectCustomerClass).change(function() {
		var selectedValue = $("."+ selectCustomerClass+" option:selected").val();
		$('input[name=customerID]').val(selectedValue);
		$('input[name=idCustomer]').val(selectedValue);
		validaForm();
	});
	
	$("select." + selectRSA).change(function() {
		var selectedValue = $("."+selectRSA+" option:selected").val();
		$('input[name=idRsa]').val(selectedValue);
		validaForm();
	});
}

function setUpNewRSA(){
	$('#'+newRSAForCustomer).click(function(event){
		createNewRSAKey_License();
		event.preventDefault();
	});
}

function addOptionRSA(data){
	var value = data;
	var text = data;
	$('select.' + selectRSA).append('<option value="'+ value +'">'+ text +'</option>');
}

function createNewRSAKey_License(){
	showLoading();
	$.ajax({
		url : RSA_CREARE_URL,
		type : "POST",
		data : null,
		contentType : 'application/json',
		success : function(data) {
			if (data && data.message ) {
				alert("New key: " + data.message);
				//tbl.ajax.reload(); //location.reload();
				addOptionRSA(data.message);
			} else {
				alert("Failed");
			}
		},
		error : function(jqXHR, textStatus,
				errorThrown) {
		},
		complete : function(data) {
			hideLoading();
		},
		timeout : 120000,
	});
}

function validaForm(){
	var idCustomer = $('input[name = '+idCustomerInput+']').val().trim();
	var idRSA = $('input[name = '+idRSAInput+']').val().trim();
	if(idCustomer.length <= 0 || idCustomer == 0 || idRSA.length <= 0 || idRSA == 0) {
		if(idCustomer.length <= 0 || idCustomer == 0){
			$('.error_customer').removeClass('hide'); 
		}
		if(idRSA.length <= 0 || idRSA == 0){
			$('.error_rsa').removeClass('hide'); 
		} 
		return false;
	} else {
		$('.error_rsa').addClass('hide');
		$('.error_customer').addClass('hide'); 
	}
}